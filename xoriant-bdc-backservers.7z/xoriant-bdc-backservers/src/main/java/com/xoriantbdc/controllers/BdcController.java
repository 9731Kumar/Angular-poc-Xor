package com.xoriantbdc.controllers;

import java.io.IOException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.xoriantbdc.dto.BulkEmployeeSaveDto;
import com.xoriantbdc.dto.EmployeeDto;
import com.xoriantbdc.dto.InvoiceDto;
import com.xoriantbdc.models.Company;
import com.xoriantbdc.models.Contract;
import com.xoriantbdc.models.Employee;
import com.xoriantbdc.models.Invoice;
import com.xoriantbdc.models.Role;
import com.xoriantbdc.service.CompanyService;
import com.xoriantbdc.service.ContractService;
import com.xoriantbdc.service.EmployeeService;
import com.xoriantbdc.service.InvoiceService;




@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/bdc")
public class BdcController {

	Logger logger = LoggerFactory.getLogger(BdcController.class);

	@Autowired
	private CompanyService companyService;

	@Autowired
	private EmployeeService employeeService;

	@Autowired
	private ContractService contractService;

	@Autowired
	private InvoiceService invoiceService;

	/*
	 * @PostMapping(value="/addcompany", consumes=
	 * {MediaType.APPLICATION_JSON_VALUE, MediaType.MULTIPART_FORM_DATA_VALUE})
	 * public Company addComapany(@RequestBody Company company, @RequestParam
	 * MultipartFile image) throws IOException { String fileName =
	 * StringUtils.cleanPath(image.getOriginalFilename());
	 * company.setLogo(fileName); Company saveCompany =
	 * companyService.saveCompanies(company);
	 * 
	 * String uploadDir = "user-photos/" + saveCompany.getCompanyId();
	 * 
	 * FileUploadUtil.saveFile(uploadDir, fileName, image);
	 * 
	 * 
	 * return saveCompany; }
	 */

	@PostMapping("/addcompany")
	public Company addComapany(@RequestBody Company company) {
		Company saveCompany = companyService.saveCompanies(company);
		return saveCompany;
	}

	@GetMapping("/companynames")
	public List<String> getAllCompaniesNames() {
		return companyService.getListOfCompanyNames();
	}

	@PostMapping("/addemployee")
	public Employee addEmployee(@RequestBody EmployeeDto employeeDto) {
		
		return employeeService.saveEmployee(employeeDto);
	}

	@GetMapping("/login/{employeeUserName}/{employeePassword}/{role}")
	public boolean validateContractManagerLogin(@PathVariable String employeeUserName,
			@PathVariable String employeePassword, @PathVariable String role) {

		try {
			return employeeService.checkManagerLogin(employeeUserName, employeePassword, role);
		} catch (Exception e) {
			return false;
		}

	}

	@PostMapping("/addcontract/{employeeUserName}")
	public Contract addContract(@RequestBody Contract contract, @PathVariable String employeeUserName) {
		return contractService.saveContract(contract, employeeUserName);
	}

	@GetMapping("/getClients")
	public List<String> getAllClients() {
		return companyService.getListOfClientCompanyNames();
	}

	@GetMapping("/getEmployeeByName/{employeeUserName}")
	public Employee getEmployee(@PathVariable String employeeUserName) {
		return employeeService.getEmployeeByUserName(employeeUserName);
	}

	@GetMapping("/getPendingContracts/{username}")
	public List<Contract> getAllPendingContracts(@PathVariable String username) {
		return contractService.getPendingContracts(username);
	}

	@PutMapping("/contractApprove/{username}")
	public boolean approveContracts(@RequestBody Contract contract, @PathVariable String username) {
		return contractService.updateContractStatus(contract, username);
	}

	@GetMapping("/getVendorPendingContracts/{username}")
	public List<Contract> getPendingContractList(@PathVariable String username) {
		return contractService.getListOfPendingContracts(username);
	}

	@GetMapping("/companies/{value}")
	public List<Company> getListOfCompanies(@PathVariable String value) {
		return companyService.getAllCompanies(value);
	}

	@GetMapping("/employees/{state}")
	public List<Employee> getListOfEmployees(@PathVariable String state) {
		return employeeService.getAllEmployees(state);
	}

	@DeleteMapping("/deleteEmployee/{id}")
	public boolean deleteEmployees(@PathVariable int id) {
		try {
			employeeService.deleteEmployeeById(id);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	@DeleteMapping("/deleteCompany/{id}")
	public boolean deleteComapany(@PathVariable int id) {
		try {
			companyService.deleteCompanyById(id);
			return true;
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
	}

	// display only contracts approved by the user
	@GetMapping("/getApprovedContracts/{userName}")
	public List<Contract> getAllApprovedContracts(@PathVariable String userName) {
		return contractService.getAllApprovedContractsForClient(userName);
	}

	@GetMapping("/getApprovedContractsVendor/{userName}")
	public List<Contract> getAllApprovedContractsForVendor(@PathVariable String userName) {
		return contractService.getAllApprovedContractsForVendor(userName);
	}

	@PostMapping("/createInvoice/{userName}")
	public Invoice createInvoice(@RequestBody InvoiceDto invoiceDto, @PathVariable String userName) {
		return invoiceService.generateInvoice(invoiceDto, userName);
	}

	@GetMapping("/getPendingInvoices/{userName}/{id}")
	public List<Invoice> getListOfPendingInvoices(@PathVariable String userName, @PathVariable String id) {
		return invoiceService.getListOfPendingInvoicesClient(userName, id);
	}

	@PutMapping("/reviewInvoice/{userName}")
	public Invoice reviewInvoiceStatus(@RequestBody InvoiceDto invoiceDto, @PathVariable String userName) {
		return invoiceService.reviewInvoice(invoiceDto, userName);
	}

	@GetMapping("/getReviewedInvoices/{userName}")
	public List<Invoice> getListOfReviwedInvoices(@PathVariable String userName) {
		return invoiceService.getListOfReviewedInvoicesClient(userName);
	}

	@GetMapping("/getReviewedInvoicesForApproval/{userName}")
	public List<Invoice> getListOfReviwedInvoicesForApproval(@PathVariable String userName) {
		return invoiceService.getListOfReviewedInvoicesForApproval(userName);
	}

	@PutMapping("/approveInvoice/{userName}")
	public Invoice approveInvoice(@RequestBody Invoice invoice, @PathVariable String userName) {
		return invoiceService.approveInvoice(invoice, userName);
	}

	@GetMapping("/getApprovedInvoices/{userName}")
	public List<Invoice> getApprovedInvoices(@PathVariable String userName) {
		return invoiceService.getApprovedInvoices(userName);
	}

	@GetMapping("/getPendingInvoicesVendor/{userName}")
	public List<Invoice> getPendingInvoicesVendor(@PathVariable String userName) {
		return invoiceService.getApprovedInvoicesVendor(userName);
	}

	@GetMapping("/getReadyToPayInvoiceForClient/{userName}")
	public List<Invoice> getListOfInvoicesReadyToPay(@PathVariable String userName) {
		return invoiceService.getApprovedInvoicesForClient(userName);
	}

	@PutMapping("/paymentSuccess/{username}")
	public Invoice invoicePaymentUpdate(@RequestBody InvoiceDto invoiceDto, @PathVariable String username) {
		return invoiceService.invoicePaymentUpdate(invoiceDto, username);
	}

	//paid invoices for client
	@GetMapping("/getPaidInvoice/{username}")
	public List<Invoice> getPaidInvoiceList(@PathVariable String username) {
		return invoiceService.getPaidInvoiceList(username);
	}
	
	//paid invoices for Vendor
	@GetMapping("/vendor/paidInvoice/{username}")
	public List<Invoice> getPaidInvoicesForVendor(@PathVariable String username){
		return invoiceService.getPaidInvoicesListForVendor(username);
	}

	@GetMapping("/getInactivateEmployees")
	public List<Employee> getInActivateEmployees() {
		return employeeService.getInActiveEmployee();
	}

	@GetMapping("/getInactivateCompany")
	public List<Company> getInActivateCompanies() {
		return companyService.getInActiveCompanies();
	}

	@PutMapping("/activateEmployee")
	public Employee activateTheEmployee(@RequestBody Employee employee) {
		return employeeService.activateEmployee(employee);
	}

	@PutMapping("/activateCompany/{activateEmployee}")
	public Company activateCompany(@RequestBody Company company, @PathVariable boolean activateEmployee) {
		return companyService.activateCompany(company, activateEmployee);
	}

	@GetMapping("/companies")
	public List<Company> getCompanies() {
		return companyService.getCompanies();
	}

	@GetMapping("/employees")
	public List<Employee> getEmployees() {
		return employeeService.getEmployees();
	}

	@PutMapping("/edit/company")
	public Company updateCompany(@RequestBody Company company) {
		return companyService.updateTheCompany(company);
	}

	@PutMapping("/edit/employee")
	public Employee updateEmployee(@RequestBody EmployeeDto employeeDto) {
		return employeeService.updateTheEmployee(employeeDto);
	}

	@GetMapping("/contracts/{username}")
	public List<Contract> getAllContracts(@PathVariable String username) {
		return contractService.getAllContracts(username);
	}

	@GetMapping("/invoices/{username}")
	public List<Invoice> getAllInvoices(@PathVariable String username) {
		return invoiceService.getAllInvoices(username);
	}
	
	@PostMapping("/savemanyemp")
	public List<BulkEmployeeSaveDto> saveManyEmployees(@RequestBody List<BulkEmployeeSaveDto> employeeDto) {
		System.out.println("check ::"+employeeDto);
		return employeeService.saveManyEmps(employeeDto);
	}

	
	@GetMapping("getroles/{id}")
	public List<Role> getRoles(@PathVariable int id){
		return employeeService.getRolesOfCompany(id);
	}
	
	
}
