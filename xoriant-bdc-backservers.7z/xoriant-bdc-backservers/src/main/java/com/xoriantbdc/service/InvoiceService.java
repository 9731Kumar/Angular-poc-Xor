package com.xoriantbdc.service;

import java.util.List;

import com.xoriantbdc.dto.InvoiceDto;
import com.xoriantbdc.models.Contract;
import com.xoriantbdc.models.Invoice;

public interface InvoiceService {

	Invoice generateInvoice(InvoiceDto invoiceDto, String userName);

	List<Invoice> getListOfPendingInvoicesClient(String userName,String id);

	Invoice reviewInvoice(InvoiceDto invoiceDto, String userName);

	List<Invoice> getListOfReviewedInvoicesClient(String userName);

	List<Invoice> getListOfReviewedInvoicesForApproval(String userName);

	Invoice approveInvoice(Invoice invoice, String userName);

	List<Invoice> getApprovedInvoices(String userName);

	List<Invoice> getApprovedInvoicesVendor(String userName);

	List<Invoice> getApprovedInvoicesForClient(String userName);

	Invoice invoicePaymentUpdate(InvoiceDto invoiceDto, String username);

	List<Invoice> getPaidInvoiceList(String username);

	List<Invoice> getAllInvoices(String username);

	List<Invoice> getPaidInvoicesListForVendor(String username);

}
