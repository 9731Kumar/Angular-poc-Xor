package com.xoriantbdc.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xoriantbdc.dto.InvoiceDto;
import com.xoriantbdc.models.Contract;
import com.xoriantbdc.models.Employee;
import com.xoriantbdc.models.Invoice;
import com.xoriantbdc.models.Status;
import com.xoriantbdc.repositories.CompanyRepository;
import com.xoriantbdc.repositories.ContractRepository;
import com.xoriantbdc.repositories.EmployeeRepositories;
import com.xoriantbdc.repositories.InvoiceRepository;

@Service
public class InvoiceServiceImpl implements InvoiceService {

	@Autowired
	private InvoiceRepository invoiceRepo;

	@Autowired
	private CompanyRepository companyRepo;

	@Autowired
	private EmployeeRepositories employeeRepo;

	@Autowired
	private ContractRepository contractRepo;

	@Override
	@Transactional
	public Invoice generateInvoice(InvoiceDto invoiceDto, String userName) {

		Employee emp = employeeRepo.findByEmployeeUserName(userName);
		Contract contract = contractRepo.findById(invoiceDto.getContractID()).get();

		Invoice invoice = new Invoice();
		invoice.setDate(LocalDate.now());
		invoice.setInvoiceRaisedBy(emp.getEmployeeName());
		invoice.setInvoiceAmount(invoiceDto.getInvoiceAmount());
		invoice.setStatus(Status.PAYMENT_PENDING);
		invoice.setContract(contract);
		Invoice save = invoiceRepo.save(invoice);
		if (save != null) {
			/*
			 * int balance = contract.getBalance() - save.getInvoiceAmount();
			 * contract.setBalance(balance);
			 */
			contractRepo.save(contract);

		}
		return save;
	}

	@Override
	public List<Invoice> getListOfPendingInvoicesClient(String userName, String id) {

		List<Invoice> invoiceList = invoiceRepo.findInvoiceByContractContractID(id);
		List<Invoice> pendingList = invoiceList.stream().filter(x -> x.getStatus().toString().equals("PAYMENT_PENDING"))
				.collect(Collectors.toList());

		return pendingList;
	}

	@Override
	public Invoice reviewInvoice(InvoiceDto invoiceDto, String userName) {
		//Contract contract = contractRepo.findById(invoiceDto.getContractID()).get();
		Employee employee = employeeRepo.findByEmployeeUserName(userName);
		Invoice invoice = invoiceRepo.findById(invoiceDto.getId()).get();
		//invoice.setContract(contract);
		invoice.setInvoiceReviewedBy(employee.getEmployeeName());
		invoice.setStatus(Status.PAYMENT_REVIEWED);
		Invoice save = invoiceRepo.save(invoice);
		return save;
	}

	@Override
	public List<Invoice> getListOfReviewedInvoicesClient(String userName) {
		Employee employee = employeeRepo.findByEmployeeUserName(userName);
		String empName = (employee.getEmployeeName());
		return invoiceRepo.findInvoiceByInvoiceReviewedBy(empName);

	}

	@Override
	public List<Invoice> getListOfReviewedInvoicesForApproval(String userName) {
		List<Invoice> invoiceList = new ArrayList<Invoice>();
		Employee employee = employeeRepo.findByEmployeeUserName(userName);
		String empName = (employee.getEmployeeName());
		List<Contract> contracts = contractRepo.findContractByContractApprovedBy(empName);
		for (Contract contract : contracts) {
			List<Invoice> invoices = invoiceRepo.findInvoiceByContractContractID(contract.getContractID());
			for (Invoice i : invoices) {
				if (i.getStatus().toString().equals("PAYMENT_REVIEWED")) {
					invoiceList.add(i);
				}
			}
		}
		return invoiceList;
	}

	@Override
	public Invoice approveInvoice(Invoice invoice, String userName) {
		Employee employee = employeeRepo.findByEmployeeUserName(userName);
		String empName = (employee.getEmployeeName());
		invoice.setStatus(Status.PAYMENT_APPROVED);
		invoice.setInvoiceApprovedBy(empName);
		return invoiceRepo.save(invoice);

	}

	@Override
	public List<Invoice> getApprovedInvoices(String userName) {
		Employee employee = employeeRepo.findByEmployeeUserName(userName);
		String empName = (employee.getEmployeeName());
		
		return invoiceRepo.findByInvoiceApprovedBy(empName);

	}

	@Override
	public List<Invoice> getApprovedInvoicesVendor(String userName) {
		Employee employee = employeeRepo.findByEmployeeUserName(userName);
		String empName = (employee.getEmployeeName());
		List<Invoice> invoiceList = invoiceRepo.findByInvoiceRaisedBy(empName);
		List<Invoice> pendingList = invoiceList.stream().filter(x -> x.getStatus().toString().equals("PAYMENT_PENDING"))
				.collect(Collectors.toList());
		return pendingList;
	}

	@Override
	public List<Invoice> getApprovedInvoicesForClient(String userName) {
		List<Invoice> invoiceList=new ArrayList<Invoice>();
		
		Employee employee = employeeRepo.findByEmployeeUserName(userName);
		List<Employee> emps = employeeRepo.findEmployeeByCompanyCompanyId(employee.getCompany().getCompanyId());
		List<String> collect = emps.stream().filter(e->e.getRole().toString().equals("CONTRACTMANAGER")).map(e->e.getEmployeeName()).collect(Collectors.toList());
		for (String name : collect) {
			List<Invoice> list = invoiceRepo.findByInvoiceApprovedBy(name);
			List<Invoice> collect2 = list.stream().filter(e->e.getStatus().toString().equals("PAYMENT_APPROVED")).collect(Collectors.toList());
			invoiceList.addAll(collect2);
		}
		
		return invoiceList;
	}

	@Override
	@Transactional
	public Invoice invoicePaymentUpdate(InvoiceDto invoiceDto, String username) {
		Contract contract = contractRepo.findById(invoiceDto.getContractID()).get();
		
		Employee employee = employeeRepo.findByEmployeeUserName(username);
		Invoice invoice = invoiceRepo.findById(invoiceDto.getId()).get();
		String empName = (employee.getEmployeeName());
		invoice.setStatus(Status.PAID);
		invoice.setInvoicePaymentMadeBy(empName);
		 Invoice save = invoiceRepo.save(invoice);
		 if(save!=null) {
			 contract.setSettledAmount(invoice.getInvoiceAmount());
			 int balance = contract.getBalance() - save.getInvoiceAmount();
			 contract.setBalance(balance);
			 contractRepo.save(contract);
			 
			 return save;
		 }
		 return null;
	}

	@Override
	public List<Invoice> getPaidInvoiceList(String username) {
		Employee employee = employeeRepo.findByEmployeeUserName(username);
		List<Invoice> paidInvoices = invoiceRepo.findByInvoicePaymentMadeBy(employee.getEmployeeName());

		return paidInvoices;
	}

	@Override
	public List<Invoice> getAllInvoices(String username) {
		Employee employee = employeeRepo.findByEmployeeUserName(username);
		List<Invoice> apprInvoices = invoiceRepo.findByInvoiceApprovedBy(employee.getEmployeeName());

		return apprInvoices;
	}

	@Override
	public List<Invoice> getPaidInvoicesListForVendor(String username) {
		Employee employee = employeeRepo.findByEmployeeUserName(username);
		List<Invoice> list = invoiceRepo.findByInvoiceRaisedBy(employee.getEmployeeName());	
		List<Invoice> paidInvoices = list.stream().filter(e->e.getStatus().toString().equals("PAID")).collect(Collectors.toList());
		return paidInvoices;
	}

}
