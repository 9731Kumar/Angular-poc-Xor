package com.xoriantbdc.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xoriantbdc.models.Company;
import com.xoriantbdc.models.Employee;
import com.xoriantbdc.models.IsActive;
import com.xoriantbdc.models.Status;
import com.xoriantbdc.repositories.CompanyRepository;
import com.xoriantbdc.repositories.EmployeeRepositories;

@Service
public class CompanyServiceImpl implements CompanyService {

	@Autowired
	private CompanyRepository companyRepo;

	@Autowired
	private EmployeeRepositories employeeRepo;

	@Override
	public Company saveCompanies(Company company) {
		company.setIsActive(IsActive.ACTIVE);

		List<Company> findAll = companyRepo.findAll();
		List<String> gstListDB = findAll.stream().map(e -> e.getGst()).collect(Collectors.toList());

		if (!gstListDB.contains(company.getGst())) {
			return companyRepo.save(company);
		}
		return null;

	}

	@Override
	public List<String> getListOfCompanyNames() {
		List<Company> companyList = companyRepo.findAll();
		List<String> companyNames = companyList.stream().filter(e -> e.getIsActive().toString().equals("ACTIVE"))
				.map(e -> e.getCompanyName()).collect(Collectors.toList());
		return companyNames;
	}

	@Override
	public List<String> getListOfClientCompanyNames() {
		List<Company> list = companyRepo.findAll();
		List<String> clients = list.stream().filter(
				e -> e.getIsActive().toString().equals("ACTIVE"))
				.map(e -> e.getCompanyName()).collect(Collectors.toList());
		return clients;
	}

	@Override
	public List<Company> getAllCompanies(String value) {
		List<Company> list = companyRepo.findAll();
		if (value.equalsIgnoreCase("ACTIVE")) {
			List<Company> activeCompanies = list.stream().filter(e -> e.getIsActive().toString().equals("ACTIVE"))
					.collect(Collectors.toList());
			return activeCompanies;
		} else if (value.equalsIgnoreCase("INACTIVE")) {
			List<Company> inActiveCompanies = list.stream().filter(e -> e.getIsActive().toString().equals("INACTIVE"))
					.collect(Collectors.toList());
			return inActiveCompanies;
		}
		
		return null;
	}

	@Override
	@Transactional
	public void deleteCompanyById(int id) {
		// Company company =companyRepo.findById(id).get();

		// Employee employee = employeeRepo.findByEmployeeUserName();
		List<Employee> list = employeeRepo.findEmployeeByCompanyCompanyId(id);
		for (Employee e : list) {
			e.setIsActive(IsActive.INACTIVE);
			employeeRepo.save(e);
		}
		Company company = companyRepo.findById(id).get();
		company.setIsActive(IsActive.INACTIVE);

		companyRepo.save(company);

	}

	@Override
	public List<Company> getInActiveCompanies() {
		List<Company> list = companyRepo.findAll();
		List<Company> inActiveCompany = list.stream().filter(e -> e.getIsActive().toString().equals("INACTIVE"))
				.collect(Collectors.toList());
		return inActiveCompany;
	}

	@Override
	public Company activateCompany(Company company, boolean activateEmployee) {
		Company cmp = companyRepo.findById(company.getCompanyId()).get();
		if (activateEmployee) {
			List<Employee> emps = employeeRepo.findEmployeeByCompanyCompanyId(cmp.getCompanyId());
			for (Employee e : emps) {
				if (e.getIsActive().toString().equals("INACTIVE")) {
					e.setIsActive(IsActive.ACTIVE);
					employeeRepo.save(e);
				}
			}
			cmp.setIsActive(IsActive.ACTIVE);
			return companyRepo.save(cmp);
		} else {
			cmp.setIsActive(IsActive.ACTIVE);
			return companyRepo.save(cmp);
		}
	}

	@Override
	public List<Company> getCompanies() {
		List<Company> list = companyRepo.findAll();
		return list;
	}

	@Override
	public Company updateTheCompany(Company company) {
		company.setIsActive(IsActive.ACTIVE);

		List<Company> findAll = companyRepo.findAll();
		List<String> gstListDB = findAll.stream().map(e -> e.getGst()).collect(Collectors.toList());
		Company company2 = companyRepo.findById(company.getCompanyId()).get();

		if (company.getGst().equals(company2.getGst())) {
			return companyRepo.save(company);
		} else if (!gstListDB.contains(company.getGst())) {
			return companyRepo.save(company);
		}
		return null;
	}

}
