package com.xoriantbdc.service;

import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;

import com.xoriantbdc.dto.BulkEmployeeSaveDto;
import com.xoriantbdc.dto.EmployeeDto;
import com.xoriantbdc.models.Employee;
import com.xoriantbdc.models.Role;

public interface EmployeeService {
	
	Employee saveEmployee(EmployeeDto employeeDto);
	
	boolean checkManagerLogin(String employeeUserName, String employeePassword, String role);
	
	Employee getEmployeeByUserName(String employeeUserName);

	List<Employee> getAllEmployees(String state);

	void deleteEmployeeById(int id);

	List<Employee> getInActiveEmployee();

	Employee activateEmployee(Employee employee);

	List<Employee> getEmployees();

	Employee updateTheEmployee(EmployeeDto employeeDto);

	List<BulkEmployeeSaveDto> saveManyEmps(List<BulkEmployeeSaveDto> employeeDto);
	
	List<Role> getRolesOfCompany(int cid);

}
