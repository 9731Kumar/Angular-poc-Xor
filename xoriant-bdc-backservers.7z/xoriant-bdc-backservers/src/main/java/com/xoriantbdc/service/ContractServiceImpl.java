package com.xoriantbdc.service;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xoriantbdc.models.Contract;
import com.xoriantbdc.models.Employee;
import com.xoriantbdc.models.IsActive;
import com.xoriantbdc.models.Status;
import com.xoriantbdc.repositories.CompanyRepository;
import com.xoriantbdc.repositories.ContractRepository;
import com.xoriantbdc.repositories.EmployeeRepositories;

@Service
public class ContractServiceImpl implements ContractService {
	
	@Autowired
	private CompanyRepository companyRepo;
	
	@Autowired
	private EmployeeRepositories employeeRepo;
	
	@Autowired
	private ContractRepository contractRepo;
	
	@Override
	public Contract saveContract(Contract contract, String employeeUserName) {
		Employee employee = employeeRepo.findByEmployeeUserName(employeeUserName);
		contract.setContractRaisedBy(employee.getEmployeeName());
		contract.setVendor(employee.getCompany().getCompanyName());
		contract.setContractDate(LocalDate.now());
		contract.setStatus(Status.PENDING);
		contract.setIsActive(IsActive.ACTIVE);
		contract.setBalance(contract.getAmount());
		Contract con = contractRepo.save(contract);
		return con;
	}
	
	@Override
	public List<Contract> getPendingContracts(String username) {
		Employee employee = employeeRepo.findByEmployeeUserName(username);
		List<Contract> list = contractRepo.findByClient(employee.getCompany().getCompanyName());
		List<Contract> pendingContracts = list.stream().filter(e->e.getStatus().toString().equals("PENDING")).collect(Collectors.toList());
		return pendingContracts;
	}
	
	@Override
	public boolean updateContractStatus(Contract contract, String username) {
		Employee employee = employeeRepo.findByEmployeeUserName(username);
		contract.setContractApprovedBy(employee.getEmployeeName());
		contract.setStatus(Status.ONGOING);
		contract.setIsActive(IsActive.ACTIVE);
		Contract save = contractRepo.save(contract);
		return true;
	}
	
	@Override
	public List<Contract> getListOfPendingContracts(String username) {
		Employee employee = employeeRepo.findByEmployeeUserName(username);
		List<Contract> list = contractRepo.findByVendor(employee.getCompany().getCompanyName());
		List<Contract> contractList = list.stream().filter(e->e.getStatus().toString().equals("PENDING")).collect(Collectors.toList());
		return contractList;
	}

	@Override
	public List<Contract> getAllApprovedContractsForClient(String userName) {
		Employee employee = employeeRepo.findByEmployeeUserName(userName);
	    List<Contract> list = contractRepo.findByClient(employee.getCompany().getCompanyName());
	    List<Contract> approvedContracts = list.stream().filter(e->e.getStatus().toString().equals("ONGOING")).collect(Collectors.toList());
		
		return approvedContracts;
	}

	
	@Override
	public List<Contract> getAllApprovedContractsForVendor(String userName) {
		Employee employee = employeeRepo.findByEmployeeUserName(userName);
	    List<Contract> list = contractRepo.findByVendor(employee.getCompany().getCompanyName());
	    List<Contract> approvedContracts = list.stream().filter(e->e.getStatus().toString().equals("ONGOING")).collect(Collectors.toList());
		return approvedContracts;
	}

	@Override
	public List<Contract> getAllContracts(String username) {
		Employee employee = employeeRepo.findByEmployeeUserName(username);
		List<Contract> list = contractRepo.findContractBycontractRaisedBy(employee.getEmployeeName());
		return list;

	}
	
}
