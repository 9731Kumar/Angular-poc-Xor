package com.xoriantbdc.service;

import java.util.List;

import com.xoriantbdc.models.Contract;

public interface ContractService {
	
	Contract saveContract(Contract contract, String employeeUserName);
	
	List<Contract> getPendingContracts(String username);
	
	boolean updateContractStatus(Contract contract, String username);
	
	List<Contract> getListOfPendingContracts(String username);

	List<Contract> getAllApprovedContractsForClient(String userName);

	List<Contract> getAllApprovedContractsForVendor(String userName);

	List<Contract> getAllContracts(String username);


}
