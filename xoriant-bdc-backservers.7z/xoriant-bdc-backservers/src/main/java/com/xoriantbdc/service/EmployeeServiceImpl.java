package com.xoriantbdc.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;

import com.xoriantbdc.dto.BulkEmployeeSaveDto;
import com.xoriantbdc.dto.EmployeeDto;
import com.xoriantbdc.models.Company;
import com.xoriantbdc.models.Employee;
import com.xoriantbdc.models.IsActive;
import com.xoriantbdc.models.Role;
import com.xoriantbdc.repositories.CompanyRepository;
import com.xoriantbdc.repositories.EmployeeRepositories;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private CompanyRepository companyRepo;

	@Autowired
	private EmployeeRepositories employeeRepo;
	
	
	
	public List<Role> getRolesOfCompany(int cid){
	

		List<Employee> emps = employeeRepo.findAll();
		List<String> empUsernames = emps.stream().map(e -> e.getEmployeeUserName()).collect(Collectors.toList());
		List<Role> roles = emps.stream().filter(x->x.getCompany().getCompanyId()==cid).map(e->e.getRole()).collect(Collectors.toList());
		return roles;
				
	}

	@Override
	public Employee saveEmployee(EmployeeDto employeeDto) {
	
		Company company = companyRepo.findByCompanyName(employeeDto.getEmployeeCompany());

		List<Employee> emps = employeeRepo.findAll();
		List<String> empUsernames = emps.stream().map(e -> e.getEmployeeUserName()).collect(Collectors.toList());
//		List<Role> roles = emps.stream().filter(x->x.getCompany().getCompanyId()==company.getCompanyId()).map(e->e.getRole()).collect(Collectors.toList());
				
				
			if (!empUsernames.contains(employeeDto.getEmployeeUserName())) {
				
			Employee emp = new Employee();
			emp.setCompany(company);
			emp.setEmployeeName(employeeDto.getEmployeeName());
			emp.setEmployeePassword(employeeDto.getEmployeePassword());
			emp.setEmployeeUserName(employeeDto.getEmployeeUserName());
			emp.setRole(employeeDto.getRole());
			emp.setIsActive(IsActive.ACTIVE);
			Employee employee = employeeRepo.save(emp);
			return employee;
		}
				
		return null;
	}

	@Override
	public boolean checkManagerLogin(String employeeUserName, String employeePassword, String role) {
		Employee employee = employeeRepo.findByEmployeeUserName(employeeUserName);
		if (employee.getEmployeePassword().equals(employeePassword) && employee.getRole().toString().equals(role)
				&& employee.getIsActive().toString().equals("ACTIVE")) {
			return true;
		}
		return false;
	}

	@Override
	public Employee getEmployeeByUserName(String employeeUserName) {
		Employee employee = employeeRepo.findByEmployeeUserName(employeeUserName);
		return employee;
	}

	@Override
	public List<Employee> getAllEmployees(String state) {
		List<Employee> list = employeeRepo.findAll();
		if(state.equalsIgnoreCase("ACTIVE")) {
		List<Employee> activeEmployees = list.stream().filter(e -> e.getIsActive().toString().equals("ACTIVE"))
				.collect(Collectors.toList());
		return activeEmployees;
		} else if(state.equalsIgnoreCase("INACTIVE")) {
			List<Employee> inactiveEmployee = list.stream().filter(e->e.getIsActive().toString().equals("INACTIVE")).collect(Collectors.toList());
			return inactiveEmployee;
		}
		return null;
	}

	@Override
	public void deleteEmployeeById(int id) {
		Employee employee = employeeRepo.findById(id).get();
		employee.setIsActive(IsActive.INACTIVE);
		// System.out.println(employee);
		employeeRepo.save(employee);
	}

	@Override
	public List<Employee> getInActiveEmployee() {
		List<Employee> list = employeeRepo.findAll();
		List<Employee> inActiveEmployees = list.stream().filter(e -> e.getIsActive().toString().equals("INACTIVE"))
				.collect(Collectors.toList());
		return inActiveEmployees;
	}

	@Override
	public Employee activateEmployee(Employee employee) {
		Employee emp = employeeRepo.findById(employee.getEmployeeId()).get();
		if (emp.getCompany().getIsActive().toString().equals("ACTIVE")) {
			emp.setIsActive(IsActive.ACTIVE);

			return employeeRepo.save(emp);
		}

		return null;
	}

	@Override
	public List<Employee> getEmployees() {
		List<Employee> list = employeeRepo.findAll();
		return list;
	}

	@Override
	public Employee updateTheEmployee(EmployeeDto employeeDto) {
		Company company = companyRepo.findByCompanyName(employeeDto.getEmployeeCompany());

		List<Employee> emps = employeeRepo.findAll();
		List<String> empUsernames = emps.stream().map(e -> e.getEmployeeUserName()).collect(Collectors.toList());
		Employee employee = employeeRepo.findById(employeeDto.getEmployeeId()).get();

		if (employeeDto.getEmployeeUserName().equals(employee.getEmployeeUserName())) {

			Employee emp = new Employee();
			emp.setEmployeeId(employeeDto.getEmployeeId());
			emp.setCompany(company);
			emp.setEmployeeName(employeeDto.getEmployeeName());
			emp.setEmployeePassword(employee.getEmployeePassword());
			emp.setEmployeeUserName(employeeDto.getEmployeeUserName());
			emp.setRole(employeeDto.getRole());
			emp.setIsActive(IsActive.ACTIVE);

			Employee employee1 = employeeRepo.save(emp);
			return employee1;

		} else if (!empUsernames.contains(employeeDto.getEmployeeUserName())) {
			Employee emp = new Employee();
			emp.setEmployeeId(employeeDto.getEmployeeId());
			emp.setCompany(company);
			emp.setEmployeeName(employeeDto.getEmployeeName());
			emp.setEmployeePassword(employee.getEmployeePassword());
			emp.setEmployeeUserName(employeeDto.getEmployeeUserName());
			emp.setRole(employeeDto.getRole());
			emp.setIsActive(IsActive.ACTIVE);

			Employee employee1 = employeeRepo.save(emp);
			return employee1;
		}
		return null;

	}

	@Override
	@Transactional
	public List<BulkEmployeeSaveDto> saveManyEmps(List<BulkEmployeeSaveDto> employeeDto) {
		List<BulkEmployeeSaveDto> empList = new ArrayList<BulkEmployeeSaveDto>();
		List<BulkEmployeeSaveDto> errList = new ArrayList<BulkEmployeeSaveDto>();
		for (BulkEmployeeSaveDto save : employeeDto) {
			Company company = companyRepo.findByCompanyName(save.getCompanyName());
			List<Employee> emps = employeeRepo.findAll();
			List<String> empUsernames = emps.stream().map(e -> e.getEmployeeUserName()).collect(Collectors.toList());
			if (!empUsernames.contains(save.getEmployeeUserName())) {
				Employee employee = new Employee();
				employee.setCompany(company);
				employee.setEmployeeName(save.getEmployeeName());
				employee.setEmployeeUserName(save.getEmployeeUserName());
				employee.setEmployeePassword(save.getEmployeePassword());
				employee.setRole(save.getRole());
				employee.setIsActive(IsActive.ACTIVE);
				empList.add(save);
				employeeRepo.save(employee);

			} else {
				// errorList.add(emp)
				System.out.println(save);
				errList.add(save);

//				return new ResponseEntity<EmployeeDto>(save, HttpStatus.NOT_ACCEPTABLE);
			}

		}
		if (errList.isEmpty()) {

			return null;

		} else {
			return errList;
			
		}

		/* return new ResponseEntity<List<Employee>>(saveAll, HttpStatus.CREATED); */

	}

}
