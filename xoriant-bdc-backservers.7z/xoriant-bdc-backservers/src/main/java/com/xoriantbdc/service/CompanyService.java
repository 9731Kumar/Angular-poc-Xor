package com.xoriantbdc.service;

import java.util.List;

import com.xoriantbdc.models.Company;

public interface CompanyService {
	
	Company saveCompanies(Company company);
	
	List<String> getListOfCompanyNames();
	
	List<String> getListOfClientCompanyNames();
	
	List<Company> getAllCompanies(String value);

	void deleteCompanyById(int id);

	List<Company> getInActiveCompanies();

	Company activateCompany(Company company, boolean activateEmployee);

	List<Company> getCompanies();

	Company updateTheCompany(Company company);

}
