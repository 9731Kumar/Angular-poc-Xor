package com.xoriantbdc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.xoriantbdc.models.Contract;
import com.xoriantbdc.models.Employee;

public interface ContractRepository extends JpaRepository<Contract, String> {

	List<Contract> findByClient(String companyName);

	List<Contract> findByVendor(String companyName);

	List<Contract> findContractByContractApprovedBy(String employeeName);

	List<Contract> findContractBycontractRaisedBy(String employeeName);

}
