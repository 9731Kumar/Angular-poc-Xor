package com.xoriantbdc.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.xoriantbdc.models.Company;

public interface CompanyRepository extends JpaRepository<Company, Integer> {

	Company findByCompanyName(String employeeCompany);

	Company findByGst(String gst);

}
