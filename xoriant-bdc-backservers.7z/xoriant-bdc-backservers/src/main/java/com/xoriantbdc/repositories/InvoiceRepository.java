package com.xoriantbdc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.xoriantbdc.models.Invoice;

public interface InvoiceRepository extends JpaRepository<Invoice, String> {

	List<Invoice> findInvoiceByContractContractID(String id);

	List<Invoice> findInvoiceByInvoiceReviewedBy(String empName);

	List<Invoice> findByInvoiceApprovedBy(String empName);

	List<Invoice> findByInvoiceRaisedBy(String empName);

	List<Invoice> findByInvoicePaymentMadeBy(String employeeName);

}
