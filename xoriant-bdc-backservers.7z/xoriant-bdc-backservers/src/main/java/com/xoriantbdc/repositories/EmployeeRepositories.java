package com.xoriantbdc.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.xoriantbdc.models.Company;
import com.xoriantbdc.models.Employee;

public interface EmployeeRepositories extends JpaRepository<Employee, Integer> {

	Employee findByEmployeeUserName(String userName);

	//@Query(value = "delete from employee where company_id=?1", nativeQuery = true)
	//void deleteByCompany(Company company);

	//void deleteByCompanyCompanyId(int id);

	void deleteEmployeeByCompanyCompanyId(int id);

	List<Employee> findEmployeeByCompanyCompanyId(int id);

	

	

	

}
