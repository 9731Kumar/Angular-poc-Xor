package com.xoriantbdc.dto;

import java.time.LocalDate;

public class InvoiceDto {
	
	private String id;
	private String contractID;
	private int balance;   
	private int amount;   
	private String client;
	private String vendor;
	private LocalDate contractDate;
	private String contractRaisedBy;
	private  int invoiceAmount;
	private String invoiceRaisedBy;
	
	public InvoiceDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public String getId() {
		return id;
	}



	public void setId(String id) {
		this.id = id;
	}



	public String getContractID() {
		return contractID;
	}

	public void setContractID(String contractID) {
		this.contractID = contractID;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public String getVendor() {
		return vendor;
	}

	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	public LocalDate getContractDate() {
		return contractDate;
	}

	public void setContractDate(LocalDate contractDate) {
		this.contractDate = contractDate;
	}

	public String getContractRaisedBy() {
		return contractRaisedBy;
	}

	public void setContractRaisedBy(String contractRaisedBy) {
		this.contractRaisedBy = contractRaisedBy;
	}

	public int getInvoiceAmount() {
		return invoiceAmount;
	}

	public void setInvoiceAmount(int invoiceAmount) {
		this.invoiceAmount = invoiceAmount;
	}

	public String getInvoiceRaisedBy() {
		return invoiceRaisedBy;
	}

	public void setInvoiceRaisedBy(String invoiceRaisedBy) {
		this.invoiceRaisedBy = invoiceRaisedBy;
	}

	public InvoiceDto(String id, String contractID, int balance, int amount, String client, String vendor,
			LocalDate contractDate, String contractRaisedBy, int invoiceAmount, String invoiceRaisedBy) {
		super();
		this.id = id;
		this.contractID = contractID;
		this.balance = balance;
		this.amount = amount;
		this.client = client;
		this.vendor = vendor;
		this.contractDate = contractDate;
		this.contractRaisedBy = contractRaisedBy;
		this.invoiceAmount = invoiceAmount;
		this.invoiceRaisedBy = invoiceRaisedBy;
	}

	@Override
	public String toString() {
		return "InvoiceDto [id=" + id + ", contractID=" + contractID + ", balance=" + balance + ", amount=" + amount
				+ ", client=" + client + ", vendor=" + vendor + ", contractDate=" + contractDate + ", contractRaisedBy="
				+ contractRaisedBy + ", invoiceAmount=" + invoiceAmount + ", invoiceRaisedBy=" + invoiceRaisedBy + "]";
	}
	

}
