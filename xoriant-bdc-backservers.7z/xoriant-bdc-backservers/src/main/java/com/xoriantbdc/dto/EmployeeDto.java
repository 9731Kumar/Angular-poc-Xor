package com.xoriantbdc.dto;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import com.xoriantbdc.models.Role;

public class EmployeeDto {
	
	private int employeeId;
	private String employeeName;
	private String employeeUserName;
	private String employeePassword;
	@Enumerated(EnumType.STRING)
	private Role role;
	private String employeeCompany;
	
	public EmployeeDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public EmployeeDto(String employeeName, String employeeUserName, String employeePassword, Role role,
			String employeeCompany) {
		super();
		this.employeeName = employeeName;
		this.employeeUserName = employeeUserName;
		this.employeePassword = employeePassword;
		this.role = role;
		this.employeeCompany = employeeCompany;
	}
	
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getEmployeeUserName() {
		return employeeUserName;
	}
	public void setEmployeeUserName(String employeeUserName) {
		this.employeeUserName = employeeUserName;
	}
	public String getEmployeePassword() {
		return employeePassword;
	}
	public void setEmployeePassword(String employeePassword) {
		this.employeePassword = employeePassword;
	}
	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}
	public String getEmployeeCompany() {
		return employeeCompany;
	}
	public void setEmployeeCompany(String employeeCompany) {
		this.employeeCompany = employeeCompany;
	}
	@Override
	public String toString() {
		return "EmployeeDto [employeeId=" + employeeId + ", employeeName=" + employeeName + ", employeeUserName="
				+ employeeUserName + ", employeePassword=" + employeePassword + ", role=" + role + ", employeeCompany="
				+ employeeCompany + "]";
	}

	
	
	
}
