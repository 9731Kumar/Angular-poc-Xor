package com.xoriantbdc.dto;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import com.xoriantbdc.models.Role;

public class BulkEmployeeSaveDto {
	
	private String employeeName;
	private String employeeUserName;
	private String employeePassword;
	@Enumerated(EnumType.STRING)
	private Role role;
	private String companyName;
	
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public String getEmployeeUserName() {
		return employeeUserName;
	}
	public void setEmployeeUserName(String employeeUserName) {
		this.employeeUserName = employeeUserName;
	}
	public String getEmployeePassword() {
		return employeePassword;
	}
	public void setEmployeePassword(String employeePassword) {
		this.employeePassword = employeePassword;
	}
	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public BulkEmployeeSaveDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BulkEmployeeSaveDto(String employeeName, String employeeUserName, String employeePassword, Role role,
			String companyName) {
		super();
		this.employeeName = employeeName;
		this.employeeUserName = employeeUserName;
		this.employeePassword = employeePassword;
		this.role = role;
		this.companyName = companyName;
	}
	@Override
	public String toString() {
		return "BulkEmployeeSaveDto [employeeName=" + employeeName + ", employeeUserName=" + employeeUserName
				+ ", employeePassword=" + employeePassword + ", role=" + role + ", companyName=" + companyName + "]";
	}
	
	

}
