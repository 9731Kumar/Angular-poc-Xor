package com.xoriantbdc.models;

public enum Status {
	
	PENDING, ONGOING, REJECTED,CLOSED,PAID,PAYMENT_PENDING,PAYMENT_REVIEWED,PAYMENT_APPROVED

}
