package com.xoriantbdc.models;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.GenericGenerator;

@Entity
public class Contract {
	
	@Id
	@GenericGenerator(name = "one", strategy = "com.xoriantbdc.util.ContractIdGenerator")
	@GeneratedValue(generator = "one")
	private String contractID;
	private String vendor;
	private String client;
	private String contractRaisedBy;
	private String contractApprovedBy;
	private String description;
	private LocalDate contractDate;
	private LocalDate contractStratDate;
	private LocalDate contractEndDate;
	private int settledAmount;
	private int balance;                             
	@Enumerated(EnumType.STRING)
	private Status status;
	private int amount;
	
	@Enumerated(EnumType.STRING)
	private IsActive isActive;

	public Contract() {
		super();
	}

	public Contract(String contractID, String vendor, String client, String contractRaisedBy, String contractApprovedBy,
			String description, LocalDate contractDate, LocalDate contractStratDate, LocalDate contractEndDate,
			int settledAmount, int balance, Status status, int amount, IsActive isActive) {
		super();
		this.contractID = contractID;
		this.vendor = vendor;
		this.client = client;
		this.contractRaisedBy = contractRaisedBy;
		this.contractApprovedBy = contractApprovedBy;
		this.description = description;
		this.contractDate = contractDate;
		this.contractStratDate = contractStratDate;
		this.contractEndDate = contractEndDate;
		this.settledAmount = settledAmount;
		this.balance = balance;
		this.status = status;
		this.amount = amount;
		this.isActive = isActive;
	}

	public String getContractID() {
		return contractID;
	}

	public void setContractID(String contractID) {
		this.contractID = contractID;
	}

	public String getVendor() {
		return vendor;
	}

	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	public String getClient() {
		return client;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public String getContractRaisedBy() {
		return contractRaisedBy;
	}

	public void setContractRaisedBy(String contractRaisedBy) {
		this.contractRaisedBy = contractRaisedBy;
	}

	public String getContractApprovedBy() {
		return contractApprovedBy;
	}

	public void setContractApprovedBy(String contractApprovedBy) {
		this.contractApprovedBy = contractApprovedBy;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public LocalDate getContractDate() {
		return contractDate;
	}

	public void setContractDate(LocalDate contractDate) {
		this.contractDate = contractDate;
	}

	public LocalDate getContractStratDate() {
		return contractStratDate;
	}

	public void setContractStratDate(LocalDate contractStratDate) {
		this.contractStratDate = contractStratDate;
	}

	public LocalDate getContractEndDate() {
		return contractEndDate;
	}

	public void setContractEndDate(LocalDate contractEndDate) {
		this.contractEndDate = contractEndDate;
	}

	public int getSettledAmount() {
		return settledAmount;
	}

	public void setSettledAmount(int settledAmount) {
		this.settledAmount = settledAmount;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public IsActive getIsActive() {
		return isActive;
	}

	public void setIsActive(IsActive isActive) {
		this.isActive = isActive;
	}

	@Override
	public String toString() {
		return "Contract [contractID=" + contractID + ", vendor=" + vendor + ", client=" + client
				+ ", contractRaisedBy=" + contractRaisedBy + ", contractApprovedBy=" + contractApprovedBy
				+ ", description=" + description + ", contractDate=" + contractDate + ", contractStratDate="
				+ contractStratDate + ", contractEndDate=" + contractEndDate + ", settledAmount=" + settledAmount
				+ ", balance=" + balance + ", status=" + status + ", amount=" + amount + ", isActive=" + isActive + "]";
	}

}
