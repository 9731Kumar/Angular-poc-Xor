package com.xoriantbdc.models;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.GenericGenerator;

@Entity
public class Invoice {
	
	@Id
	@GenericGenerator(name = "inv", strategy = "com.xoriantbdc.util.InvoiceIdGenerator")
	@GeneratedValue(generator = "inv")
	private String id;
	private LocalDate date;
	private String invoiceRaisedBy;
	private String invoiceApprovedBy;
	private String invoiceReviewedBy;
	private String invoicePaymentMadeBy;
	private int invoiceAmount;
	@Enumerated(EnumType.STRING)
	private Status status;
	@ManyToOne
	@JoinColumn(name = "contractId")
	private Contract contract;
	
	
	public Invoice() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public Invoice(String id, LocalDate date, String invoiceRaisedBy, String invoiceApprovedBy, String invoiceReviewedBy,
			String invoicePaymentMadeBy, int invoiceAmount, Status status, Contract contract) {
		super();
		this.id = id;
		this.date = date;
		this.invoiceRaisedBy = invoiceRaisedBy;
		this.invoiceApprovedBy = invoiceApprovedBy;
		this.invoiceReviewedBy = invoiceReviewedBy;
		this.invoicePaymentMadeBy = invoicePaymentMadeBy;
		this.invoiceAmount = invoiceAmount;
		this.status = status;
		this.contract = contract;
	}


	public String getInvoiceReviewedBy() {
		return invoiceReviewedBy;
	}
	public void setInvoiceReviewedBy(String invoiceReviewedBy) {
		this.invoiceReviewedBy = invoiceReviewedBy;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public String getInvoiceRaisedBy() {
		return invoiceRaisedBy;
	}
	public void setInvoiceRaisedBy(String invoiceRaisedBy) {
		this.invoiceRaisedBy = invoiceRaisedBy;
	}
	public String getInvoiceApprovedBy() {
		return invoiceApprovedBy;
	}
	public void setInvoiceApprovedBy(String invoiceApprovedBy) {
		this.invoiceApprovedBy = invoiceApprovedBy;
	}
	public int getInvoiceAmount() {
		return invoiceAmount;
	}
	public void setInvoiceAmount(int invoiceAmount) {
		this.invoiceAmount = invoiceAmount;
	}
	public Status getStatus() {
		return status;
	}
	public void setStatus(Status status) {
		this.status = status;
	}
	public Contract getContract() {
		return contract;
	}
	public void setContract(Contract contract) {
		this.contract = contract;
	}
	
	public String getInvoicePaymentMadeBy() {
		return invoicePaymentMadeBy;
	}
	public void setInvoicePaymentMadeBy(String invoicePaymentMadeBy) {
		this.invoicePaymentMadeBy = invoicePaymentMadeBy;
	}


	@Override
	public String toString() {
		return "Invoice [id=" + id + ", date=" + date + ", invoiceRaisedBy=" + invoiceRaisedBy + ", invoiceApprovedBy="
				+ invoiceApprovedBy + ", invoiceReviewedBy=" + invoiceReviewedBy + ", invoicePaymentMadeBy="
				+ invoicePaymentMadeBy + ", invoiceAmount=" + invoiceAmount + ", status=" + status + ", contract="
				+ contract + "]";
	}
	
	

}
