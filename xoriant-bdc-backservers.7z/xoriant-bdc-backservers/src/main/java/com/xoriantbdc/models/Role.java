package com.xoriantbdc.models;

public enum Role {
	CONTRACTMANAGER, PROJECTMANAGER, ACCOUNTANTMANAGER, ADMIN ;

}
