package com.xoriantbdc.models;

import java.util.List;


import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Company {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int companyId;
	private String companyName;
	private String companyEmail;
	private String companyLocation;
	private String companyService;
	private String gst;
	private String logo;

//	@Enumerated(EnumType.STRING)
//	private CompanyType companyType;
	@Enumerated(EnumType.STRING)
	private IsActive isActive;

	@JsonIgnore
	@OneToMany(mappedBy = "company")
	private List<Employee> employees;

	public Company() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Company(int companyId, String companyName, String companyEmail, String companyLocation,
			String companyService, String gst, String logo, IsActive isActive,
			List<Employee> employees) {
		super();
		this.companyId = companyId;
		this.companyName = companyName;
		this.companyEmail = companyEmail;
		this.companyLocation = companyLocation;
		this.companyService = companyService;
		this.gst = gst;
		this.logo = logo;
		
		this.isActive = isActive;
		this.employees = employees;
	}

	public int getCompanyId() {
		return companyId;
	}

	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCompanyEmail() {
		return companyEmail;
	}

	public void setCompanyEmail(String companyEmail) {
		this.companyEmail = companyEmail;
	}

	public String getCompanyLocation() {
		return companyLocation;
	}

	public void setCompanyLocation(String companyLocation) {
		this.companyLocation = companyLocation;
	}

	public String getCompanyService() {
		return companyService;
	}

	public void setCompanyService(String companyService) {
		this.companyService = companyService;
	}

	
	public IsActive getIsActive() {
		return isActive;
	}

	public void setIsActive(IsActive isActive) {
		this.isActive = isActive;
	}

	public List<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}

	public String getGst() {
		return gst;
	}

	public void setGst(String gst) {
		this.gst = gst;
	}

	public String getLogo() {
		return logo;
	}

	public void setLogo(String logo) {
		this.logo = logo;
	}

	@Override
	public String toString() {
		return "Company [companyId=" + companyId + ", companyName=" + companyName + ", companyEmail=" + companyEmail
				+ ", companyLocation=" + companyLocation + ", companyService=" + companyService + ", gst=" + gst
				+ ", logo=" + logo + ", isActive=" + isActive + ", employees="
				+ employees + "]";
	}

}
