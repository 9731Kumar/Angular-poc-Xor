package com.xoriantbdc.models;

public enum IsActive {
	ACTIVE, INACTIVE

}
