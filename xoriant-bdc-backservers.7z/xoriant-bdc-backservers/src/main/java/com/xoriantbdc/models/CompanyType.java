package com.xoriantbdc.models;

public enum CompanyType {
	
	VENDOR, CLIENT

}
