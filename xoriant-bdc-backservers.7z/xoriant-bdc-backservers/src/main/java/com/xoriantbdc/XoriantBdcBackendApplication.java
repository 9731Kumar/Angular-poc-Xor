package com.xoriantbdc;

import org.apache.catalina.connector.Connector;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.embedded.tomcat.TomcatConnectorCustomizer;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.server.WebServerFactoryCustomizer;
import org.springframework.boot.web.servlet.server.ConfigurableServletWebServerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

@SpringBootApplication
public class XoriantBdcBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(XoriantBdcBackendApplication.class, args);
		
	}
	
//	@Bean
//	public WebServerFactoryCustomizer<TomcatServletWebServerFactory> 
//	    containerCustomizer(){
//	    return new EmbeddedTomcatCustomizer();
//	}
//
//	private static class EmbeddedTomcatCustomizer implements WebServerFactoryCustomizer<TomcatServletWebServerFactory> {
//
//	    @Override
//	    public void customize(TomcatServletWebServerFactory factory) {
//	        factory.addConnectorCustomizers((TomcatConnectorCustomizer) connector -> {
//	            connector.setAttribute("relaxedPathChars", "<>[\\]^`{|}");
//	            connector.setAttribute("relaxedQueryChars", "<>[\\]^`{|}");
//	        });
//	    }
//	}
//	
//	
//    //@Bean
//    public MultipartResolver multipartResolver() {
//        CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver();
//        multipartResolver.setMaxUploadSize(500000000);
//        return multipartResolver;
//    }
	

}
