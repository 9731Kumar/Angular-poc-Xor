package com.xoriantbdc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XoriantBdcBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
