import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CompanyOnboardingComponent } from './admin/company/company-onboarding/company-onboarding.component';
import { CompanyListComponent } from './admin/company/company-list/company-list.component';
import { EmployeeOnboardingComponent } from './admin/employee/employee-onboarding/employee-onboarding.component';
import { EmployeeListComponent } from './admin/employee/employee-list/employee-list.component';
import { AdminHomeComponent } from './admin/admin-home/admin-home.component';
import { AdminDashboardComponent } from './admin/admin-dashboard/admin-dashboard.component';
import { SidebarComponent } from './shared/sidebar/sidebar.component';
import { LoginUserComponent } from './login-user/login-user.component';
import { ContractHomeComponent } from './contract-manager/contract-home/contract-home.component';
import { ContractDashboardComponent } from './contract-manager/contract-dashboard/contract-dashboard.component';
import { ContractCreationComponent } from './contract-manager/contract-creation/contract-creation.component';
import { ContractPendingComponent } from './contract-manager/contract-pending/contract-pending.component';
import { ContractApprovedComponent } from './contract-manager/contract-approved/contract-approved.component';
import { ContractReadytoApprovedComponent } from './contract-manager/contract-readyto-approved/contract-readyto-approved.component';
import { ApprovalPendingInvoiceComponent } from './contract-manager/approval-pending-invoice/approval-pending-invoice.component';
import { ApprovedInvoicesComponent } from './contract-manager/approved-invoices/approved-invoices.component';
import { AccHomeComponent } from './account-manager/acc-home/acc-home.component';
import { AccDashboardComponent } from './account-manager/acc-dashboard/acc-dashboard.component';
import { GenerateInvoiceComponent } from './account-manager/invoices/generate-invoice/generate-invoice.component';
import { PendingInvoiceComponent } from './account-manager/invoices/pending-invoice/pending-invoice.component';
import { PaidInvoiceComponent } from './account-manager/invoices/paid-invoice/paid-invoice.component';
import { ClosedInvoiceComponent } from './account-manager/invoices/closed-invoice/closed-invoice.component';
import { ReadyToPayinvoicesComponent } from './account-manager/payments/ready-to-payinvoices/ready-to-payinvoices.component';
import { ClientPaidInvoicesComponent } from './account-manager/payments/client-paid-invoices/client-paid-invoices.component';
import { ProjectManagerHomeComponent } from './project-manager/project-manager-home/project-manager-home.component';
import { InvoiceReviewComponent } from './project-manager/invoice-review/invoice-review.component';
import { ReviewedInvoiceListComponent } from './project-manager/reviewed-invoice-list/reviewed-invoice-list.component';
import { ProjectDashboardComponent } from './project-manager/project-dashboard/project-dashboard.component';
import { InactiveCompaniesComponent } from './admin/inactive-data/inactive-companies/inactive-companies.component';
import { InactiveEmployeesComponent } from './admin/inactive-data/inactive-employees/inactive-employees.component';
import { ClientApprovedContractsListComponent } from './contract-manager/client-approved-contracts-list/client-approved-contracts-list.component';
import { ProfileComponent } from './shared/profile/profile.component';

const routes: Routes = [
  {path:'loginuser',component: LoginUserComponent},
  { path: '', redirectTo: 'loginuser', pathMatch: 'full' },
  {
    path: 'admin-home', children: [
      { path: 'admindashboard', component: AdminDashboardComponent},
      { path: 'addEmployee/:company', component: EmployeeOnboardingComponent},
      { path: 'addEmployee', component: EmployeeOnboardingComponent},
      { path: 'addCompany', component: CompanyOnboardingComponent},
      {path:'listEmployee',component: EmployeeListComponent},
      {path:'listCompany',component: CompanyListComponent},
     // {path:'inactivecompanies',component: InactiveCompaniesComponent},
      //{path:'inactiveemployees',component: InactiveEmployeesComponent}

    ], component: AdminHomeComponent
  },
  {
    path: 'contract-home', children: [
      { path: 'contract-dashboard', component: ContractDashboardComponent},
      { path: 'contract-creation', component: ContractCreationComponent},
      { path: 'contract-approved', component: ContractApprovedComponent},
      {path:'contract-pending',component: ContractPendingComponent},
      {path:'ready-to-approve',component:ContractReadytoApprovedComponent},
      {path:'pendingapproval-invoice',component:ApprovalPendingInvoiceComponent},
      {path:'approved-invoice',component:ApprovedInvoicesComponent},
      {path:'client-contract-approved',component:ClientApprovedContractsListComponent}
     
    ], component: ContractHomeComponent
  },
  {
    path: 'account-dashboard', children: [
      { path: 'home', component: AccHomeComponent},
      { path: 'generate-invoice', component: GenerateInvoiceComponent},
      { path: 'pending-invoices', component: PendingInvoiceComponent},
      { path: 'paid-invoices', component: PaidInvoiceComponent},
      { path: 'closed-invoices', component: ClosedInvoiceComponent},
      { path: 'payment-process', component: ReadyToPayinvoicesComponent},
      { path: 'payment-done', component: ClientPaidInvoicesComponent},
    ], component: AccDashboardComponent

  },
  {
    path: 'project-dashboard', children: [
      { path: 'home', component: ProjectManagerHomeComponent},
      { path: 'invoice-review', component: InvoiceReviewComponent},
      { path: 'reviewed-invoices-list', component: ReviewedInvoiceListComponent},

      
    ], component: ProjectDashboardComponent

  },
  {path:'profile',component: ProfileComponent}
  
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponent=[ CompanyOnboardingComponent,
  CompanyListComponent,
  EmployeeOnboardingComponent,
  EmployeeListComponent,
  AdminHomeComponent,
  AdminDashboardComponent,
  SidebarComponent,ContractHomeComponent,ContractDashboardComponent,
  ContractCreationComponent,
  ContractPendingComponent,
  ContractApprovedComponent,ContractReadytoApprovedComponent,
  ContractReadytoApprovedComponent,
  InvoiceReviewComponent,
  ProjectManagerHomeComponent,
  ApprovalPendingInvoiceComponent,
  ApprovedInvoicesComponent,
  AccHomeComponent,
  AccDashboardComponent,
  GenerateInvoiceComponent,
  PendingInvoiceComponent,
  PaidInvoiceComponent,
  ClosedInvoiceComponent,
  ReadyToPayinvoicesComponent,
  ClientPaidInvoicesComponent,
  ProjectDashboardComponent,
  ReviewedInvoiceListComponent,
  InactiveCompaniesComponent,
  InactiveEmployeesComponent,];