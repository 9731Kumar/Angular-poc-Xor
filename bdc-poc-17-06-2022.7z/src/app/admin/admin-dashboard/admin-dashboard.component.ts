import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiServiceService } from 'src/app/services/api-service.service';
import { AuthenticateServiceService } from 'src/app/services/authenticate-service.service';
import Chart from 'chart.js/auto';


@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {
       totalCompanies:number = 0;
       totalEmployees: number=0;
       totalActiveEmployee:any
       totalInactiveEmployee:any;
       totalActiveCompanies:any;
       totalInactiveCompanies:any;

      
  userName!:any;
  constructor( public service:AuthenticateServiceService, private router:Router
    , private apiService:ApiServiceService){
  }
  

  ngOnInit(): void {
    //console.log(this.totalEmployees);
    this.getAllEmployees();
  }
 


  myChart(){
       
    const ctx = 'myChart';
    console.log("chart called");
    // this.getAllCompanies();
    // this.getAllEmployees();
    //this.getEmployees();
    
    const myChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['no of companies', 'no of employees', 'Inactive employees', 'Active Employees','Active companies'],
            datasets: [{
                label: '# total',
                data:[this.totalCompanies,this.totalEmployees, this.totalInactiveEmployee, this.totalActiveEmployee, this.totalActiveCompanies ],
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)',
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(153, 102, 255, 0.2)',
                    'rgba(255, 159, 64, 0.2)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 159, 64, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
    this.userName=sessionStorage.getItem('userName');   
  }

  
  adminSignOut(){
    sessionStorage.removeItem('userName');
    sessionStorage.removeItem('role');
    this.router.navigate(['loginuser'])
  }

getAllCompanies(){
  this.apiService.getAllCompanies().subscribe(res=>{
         this.totalCompanies=res.length;

         const active=res.filter((obj:any)=>{
          return obj.isActive === 'ACTIVE'
        });
        this.totalActiveCompanies=active.length;
        const inactive=res.filter((obj:any)=>{
          return obj.isActive === 'INACTIVE'
        });
        this.totalInactiveCompanies=inactive.length;
        this.myChart();
  })
}
getAllEmployees(){
  this.apiService.getAllEmployees().subscribe(res=>{
    console.log("get emp called");
    
         this.totalEmployees=res.length;
         console.log("length :"+this.totalEmployees);
         
         const active=res.filter((obj:any)=>{
           return obj.isActive === 'ACTIVE'
         });
         this.totalActiveEmployee=active.length;

         const inActive=res.filter((obj:any)=>{
          return obj.isActive === 'INACTIVE'
        });
        this.totalInactiveEmployee=inActive.length
        console.log(res.length);
        this.getAllCompanies();
        
  })
}

}

