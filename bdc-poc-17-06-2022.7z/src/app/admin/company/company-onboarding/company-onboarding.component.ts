import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiServiceService } from 'src/app/services/api-service.service';
import { ConfirmDialogService } from 'src/app/confirm-dialog/confirm-dialog.service';

@Component({
  selector: 'app-company-onboarding',
  templateUrl: './company-onboarding.component.html',
  styleUrls: ['./company-onboarding.component.css']
})
export class CompanyOnboardingComponent implements OnInit {

  companyOnboardForm!:FormGroup;
  emailPattern = "^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$";
  isCompanyAdded!:boolean;
  test:any;
  test1:any;
  companyName!:String;

  constructor(private apiService:ApiServiceService, private router:Router,private confirmDialogService:ConfirmDialogService) { }

  ngOnInit(): void {
    this.companyOnboardForm=new FormGroup({
      companyName:new FormControl('',[Validators.required, Validators.minLength(2)]),
      companyEmail:new FormControl('',[Validators.required, Validators.minLength(3), Validators.pattern(this.emailPattern)]),
      companyLocation:new FormControl('',[Validators.required, Validators.minLength(3)]),
      companyService:new FormControl('',[Validators.required, Validators.minLength(3)]),
      gst:new FormControl('',[Validators.required, Validators.minLength(6),Validators.maxLength(6)]),
      logo:new FormControl('')
    })
  }

  get f(){
    return this.companyOnboardForm.controls;
  }

  onSubmit(){
     this.companyName=this.companyOnboardForm.value.companyName;
    //this.companyName=this.companyOnboardForm.get('companyName')?.value;
    
    this.apiService.saveCompany(this.companyOnboardForm.value).subscribe(
      result =>  
      { 
        if(result!== null){
          this.isCompanyAdded=true;
          
           // alert("Company Successfully Registered Your CompanyID is @"+result.companyId)
          this.companyOnboardForm.reset();
          //this.router.navigate(['admin-home/addEmployee']);
        }
        else{
          // this.confirmDialogService.confirmThis("Company Already Exists!!!", function () {  
          //   //alert("Yes clicked");  
          // })  
          this.isCompanyAdded=false;

        }      
      })
  }

  toAddEmployee(){
    this.apiService.companyName=this.companyName;
    //console.log(this.companyName);
    
    this.router.navigate(['admin-home/addEmployee/',this.companyName]);
    //this.router.navigate(['admin-home/addEmployee/']);

    }

    
  
}