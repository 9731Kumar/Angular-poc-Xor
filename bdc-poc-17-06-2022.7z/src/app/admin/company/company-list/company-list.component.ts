import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ApiServiceService } from 'src/app/services/api-service.service';
import { ReportGenerateService } from 'src/app/services/report-generate.service';
import { ConfirmDialogService } from 'src/app/confirm-dialog/confirm-dialog.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-company-list',
  templateUrl: './company-list.component.html',
  styleUrls: ['./company-list.component.css']
})
export class CompanyListComponent implements OnInit {
  editCompanyData:any;
  companyList:any[]=[];
  editCompanyForm!:FormGroup;
  companyId:any;
  emailPattern = "^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$";
  count:number = 5;
  p:number = 1;
  searchText:any;
  
  state:string='';
  isActive!: boolean;
  company:any;
  activateEmployee:boolean=false;


  constructor(private activatedRoute:ActivatedRoute, private apiService:ApiServiceService, private reportGenerate:ReportGenerateService,private confirmDialogService:ConfirmDialogService) { }

  ngOnInit(): void {
    this.getQueryParams();
    //this.getCompanyList(this.state);
    this.editCompanyForm=new FormGroup({
      companyId:new FormControl(''),
      companyName:new FormControl('',[Validators.required, Validators.minLength(2)]),
      companyEmail:new FormControl('',[Validators.required, Validators.minLength(3), Validators.pattern(this.emailPattern)]),
      companyLocation:new FormControl('',[Validators.required, Validators.minLength(3)]),
      companyService:new FormControl('',[Validators.required, Validators.minLength(3)]),
      gst:new FormControl('',[Validators.required, Validators.minLength(5)]),
      companyType:new FormControl('',[Validators.required])
    })
  }

  getQueryParams(){
    this.activatedRoute.queryParams.subscribe(params=>{
      // console.log(params);
      // console.log(params['list']);
      this.state=params['list'];
      this.getCompanyList(this.state);
     //console.log(this.state);
      
    })
  }

  key:string='id';
  reverse:boolean=false
  Sort(key:any){
   this.key=key;
   this.reverse=!this.reverse;
  }

  
  get f(){
    return this.editCompanyForm.controls;
  }

  getCompanyList(state:string){
    this.apiService.getCompanyList(state).subscribe(res=>{
      //console.log(res);
      this.companyList=res;
    })
  }

  onDeleteCompany(id:any){
    this.companyId=id;
  }

  deleteCompany(){
    let id=this.companyId;
    this.apiService.deleteCompany(id).subscribe(res=>{
      if(res){
        this.getCompanyList(this.state);
      }else{
        this.confirmDialogService.confirmThis("Server Error", function () {  
       
        })
      }
    })
  }
  editCompany(data:any){
      this.editCompanyData=data;
      this.editCompanyForm.controls['companyId'].setValue(data.companyId);
      this.editCompanyForm.controls['companyName'].setValue(data.companyName);
      this.editCompanyForm.controls['companyEmail'].setValue(data.companyEmail);
      this.editCompanyForm.controls['companyLocation'].setValue(data.companyLocation);
      this.editCompanyForm.controls['companyService'].setValue(data.companyService);
      this.editCompanyForm.controls['gst'].setValue(data.gst);
      this.editCompanyForm.controls['companyType'].setValue(data.companyType)
   
  }

  update(){
    this.apiService.updateCompany(this.editCompanyForm.value).subscribe(res=>{
      console.log(res);
      if(res!==null){
           this.confirmDialogService.confirmThis("Company updated successfully!!!", function () {  
          
        })
        this.getCompanyList(this.state);
        
      }else{
        this.confirmDialogService.confirmThis("Company already exists!!!", function () {  
       
        })
      }
     
    })
  }

  activeCompanyList(c:any){
    this.company=c;
  }

  activateCompanyWithEmployee(){
    this.activateEmployee=true;
    this.apiService.activateCompany(this.company,this.activateEmployee).subscribe(res=>{
        this.getCompanyList(this.state);
        this.confirmDialogService.confirmThis("Company Activated with Employee", function () {  
         
        })
    })

  }

  activateCompanyOnly(){
    this.activateEmployee=false;
    this.apiService.activateCompany(this.company,this.activateEmployee).subscribe(res=>{
        this.getCompanyList(this.state);
    })

  }

  fileDownload(){

    //Headers for CSV file
    let headers=['Company Id','Company Name', 'Email', 'Service','Location','Type'];
    
    //HeaderList for iterating the array
    let headerList=['companyId','companyName','companyEmail','companyService','companyLocation','companyType'];

    this.reportGenerate.downloadFile(this.companyList,'company list',headers,headerList);
  }
  

}