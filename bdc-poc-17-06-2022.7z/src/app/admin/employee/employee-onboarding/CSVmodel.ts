
export class EmployeeRecord {  
    public employeeName: any;  
    public employeeUserName: any;  
    public employeePassword: any;  
    public role: any;  
    public companyName: any; 
     
  } 