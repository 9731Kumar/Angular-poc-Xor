import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ConfirmDialogService } from 'src/app/confirm-dialog/confirm-dialog.service';
import { EmployeeReport } from 'src/app/modal/employee-report';
import { ApiServiceService } from 'src/app/services/api-service.service';
import { ReportGenerateService } from 'src/app/services/report-generate.service';
import { EmployeeRecord } from './CSVmodel';




@Component({
  selector: 'app-employee-onboarding',
  templateUrl: './employee-onboarding.component.html',
  styleUrls: ['./employee-onboarding.component.css']
})
export class EmployeeOnboardingComponent implements OnInit {

  empOnboardForm!: FormGroup;
  companyName!: String;
  empReportList: any[] = [];
  companyList: any[] = [];
  empList: any = []
  notSavedEmpList: any[] = [];
  savedEmpList: any[] = [];
  isFailed: boolean = false;
  isSuccess: boolean = false;
  empArr: any[] = [];
  test:any[]=[];

  constructor(private apiService: ApiServiceService, private activeRouter: ActivatedRoute,
     private reportGenerate: ReportGenerateService,private confirmDialogService:ConfirmDialogService) { }

  ngOnInit(): void {
    this.companyName=this.activeRouter.snapshot.params['company'];
    // console.log(this.companyName);
    //this.companyName = this.apiService.companyName;

    this.getCompaniesList();

    this.empOnboardForm = new FormGroup({
      employeeName: new FormControl('', [Validators.required, Validators.minLength(3)]),
      employeeUserName: new FormControl('', [Validators.required, Validators.minLength(4)]),
      employeePassword: new FormControl('', [Validators.required, Validators.minLength(4)]),
      role: new FormControl('', [Validators.required]),
      employeeCompany: new FormControl(this.companyName, [Validators.required])
    })
  }

  getCompaniesList() {
    this.apiService.getCompanies().subscribe(res => {
      this.companyList = res;
    })
  }

  get f() {
    return this.empOnboardForm.controls;
  }

  onSubmit() {

    console.log(this.empOnboardForm.value);
    this.apiService.saveEmployee(this.empOnboardForm.value).subscribe(res => {
      console.log(res);
      if (res !== null) {
        this.confirmDialogService.confirmThis("Employee added successfully!!!", function () {  
          
        })
        this.empOnboardForm.reset();
        this.empOnboardForm.controls['employeeCompany'].setValue(this.companyName)

      } else {
        this.confirmDialogService.confirmThis("Username Already Exists. Try with different username ", function () {  
        })
      
      }
    })
  }
  title = 'Angular7-readCSV';

  public records: any[] = [];
  @ViewChild('csvReader') csvReader: any;

  uploadListener($event: any): void {

    let text = [];
    let files = $event.srcElement.files;

    if (this.isValidCSVFile(files[0])) {

      let input = $event.target;
      let reader = new FileReader();
      reader.readAsText(input.files[0]);

      reader.onload = () => {
        let csvData = reader.result;
        let csvRecordsArray = (<string>csvData).split(/\r\n|\n/);

        let headersRow = this.getHeaderArray(csvRecordsArray);

        this.records = this.getDataRecordsArrayFromCSVFile(csvRecordsArray, headersRow.length);
      };

      reader.onerror = function () {
        console.log('error is occured while reading file!');
      };

    } else {
      this.confirmDialogService.confirmThis("Please import valid Csv file ", function () {  
      })
    
      this.fileReset();
    }
  }

  getDataRecordsArrayFromCSVFile(csvRecordsArray: any, headerLength: any) {


    for (let i = 1; i < csvRecordsArray.length; i++) {
      let curruntRecord = (<string>csvRecordsArray[i]).split(',');
      if (curruntRecord.length == headerLength) {
        let csvRecord: EmployeeRecord = new EmployeeRecord();
        csvRecord.employeeName = curruntRecord[0].trim();
        csvRecord.employeeUserName = curruntRecord[1].trim();
        csvRecord.employeePassword = curruntRecord[2].trim();
        csvRecord.role = curruntRecord[3].trim();
        csvRecord.companyName = curruntRecord[4].trim();

        this.empArr.push(csvRecord);

      }

    }
    this.apiService.saveManyEmp(this.empArr).subscribe(res => {

      console.log(res);

      if (res == null) {
        this.savedEmpList = []
        console.log("null check::" + res);

        this.savedEmpList = this.empArr;

        this.isSuccess = true
        this.confirmDialogService.confirmThis("All employee details saved successfully!!", function () {  
        })
      

      } else if (res.length === this.empArr.length) {
        this.notSavedEmpList = res;
        this.isFailed = true;
        this.confirmDialogService.confirmThis("No employees saved", function () {  
        })
      } else if (res.length < this.empArr.length) {
        this.confirmDialogService.confirmThis("Some Employees are Not saved....try with different username", function () {  
        })
      
        console.log(res);
     
        // this.test=this.empArr
        // console.log(this.test);
        
        // let count=0;
        // for (let arr of this.empArr) {
        //   for (let arr2 of res) {
        //     if (arr.employeeUserName == arr2.employeeUserName) {
        //       console.log("index::"+this.test.indexOf(arr));
              
        //       this.test.splice(this.test.indexOf(arr),1);
        //       console.log("test length"+this.test.length);
              
                             
        //     }
        //   }
        //   count++;
        // }
     //   console.log("in some saved ::" + this.test);
        this.notSavedEmpList = res;
        console.log("in some :::" + this.notSavedEmpList);
        this.isFailed = true;
      //  this.isSuccess = true

      }

    })
    return this.empArr;
  }

  isValidCSVFile(file: any) {
    return file.name.endsWith(".csv");
  }

  getHeaderArray(csvRecordsArr: any) {
    let headers = (<string>csvRecordsArr[0]).split(',');
    let headerArray = [];
    for (let j = 0; j < headers.length; j++) {
      headerArray.push(headers[j]);
    }
    return headerArray;
  }

  fileReset() {
    this.csvReader.nativeElement.value = "";
    this.records = [];
  }

  fileDownload() {

    for (let e of this.notSavedEmpList) {
      let employee = new EmployeeReport(
        e.companyId, e.employeeName, e.employeeUserName, e.companyName, e.role
      )
      this.empReportList.push(employee);
    }
    this.notSavedEmpList = []
    console.log("empreport list::" + this.empReportList);



    //Headers for CSV file
    let headers = ['Employee Name', 'Username', 'Company', 'Role'];

    //HeaderList for iterating the array
    let headerList = ['employeeName', 'employeeUserName', 'companyName', 'role'];

    this.reportGenerate.downloadFile(this.empReportList, 'Not Saved employee list', headers, headerList);
  }

  fileDownload1() {

    for (let e of this.savedEmpList) {
      let employee = new EmployeeReport(
        e.companyId, e.employeeName, e.employeeUserName, e.companyName, e.role
      )
      this.empReportList.push(employee);
    }
    this.test = []

    console.log("empreport list::" + this.empReportList);



    //Headers for CSV file
    let headers = ['Employee Name', 'Username', 'Company', 'Role'];

    //HeaderList for iterating the array
    let headerList = ['employeeName', 'employeeUserName', 'companyName', 'role'];

    this.reportGenerate.downloadFile(this.empReportList, 'Saved employee list', headers, headerList);
  }

}

