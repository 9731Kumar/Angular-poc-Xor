import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { EmployeeReport } from 'src/app/modal/employee-report';
import { ApiServiceService } from 'src/app/services/api-service.service';
import { ReportGenerateService } from 'src/app/services/report-generate.service';
import { ConfirmDialogService } from 'src/app/confirm-dialog/confirm-dialog.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  employeeList: any[] = [];
  empEditForm!: FormGroup;
  companyList: any[] = [];
  employeeId: any;
  count: number = 5;
  p: number = 1;
  searchText: any;
  check: number = 1;
  empDisplayList: EmployeeReport[] = []
  EmployeeReportList: EmployeeReport[] = [];

  state:string="";



  constructor(private activatedRoute:ActivatedRoute ,private apiService: ApiServiceService, private reportGenerate: ReportGenerateService,private confirmDialogService:ConfirmDialogService) { }

  ngOnInit(): void {
    this.getQueryParams();
    //this.getEmployeesList(this.state);
    this.empEditForm = new FormGroup({
      employeeId: new FormControl(''),
      employeeName: new FormControl('', [Validators.required, Validators.minLength(3)]),
      employeeUserName: new FormControl('', [Validators.required, Validators.minLength(4)]),
      employeePassword: new FormControl('', [Validators.required, Validators.minLength(4)]),
      role: new FormControl('', [Validators.required]),
      employeeCompany: new FormControl('', [Validators.required])
    })
  }

  getQueryParams(){
    this.activatedRoute.queryParams.subscribe(params=>{
      this.state=params['list'];
      console.log(this.state);
      this.getEmployeesList(this.state)
      
    })

  }

  get f() {
    return this.empEditForm.controls;
  }

  key: string = 'id';
  reverse: boolean = false
  Sort(key: any) {
    this.key = key;
    this.reverse = !this.reverse;
  }

  getEmployeesList(state:string) {
    this.apiService.getEmployeeList(state).subscribe(res => {
      this.employeeList = res;
      this.empDisplayList = []
      for (let e of this.employeeList) {
        let employee = new EmployeeReport(
          e.employeeId, e.employeeName, e.employeeUserName, e.company.companyName, e.role
        )
        this.empDisplayList.push(employee);
      }

    })
  }

  deleteEmployee() {
    this.apiService.deleteEmployee(this.employeeId).subscribe(res => {
      if (res) {
        this.getQueryParams();
       // this.getEmployeesList(this.state);
      } else {
        this.confirmDialogService.confirmThis("Server Error", function () {  
       
        })
      }
    })

  }
  editEmployee(data: any) {
    this.empEditForm.controls['employeeId'].setValue(data.employeeId);
    this.empEditForm.controls['employeeName'].setValue(data.employeeName);
    this.empEditForm.controls['employeeUserName'].setValue(data.employeeUserName);
    this.empEditForm.controls['employeePassword'].setValue(data.employeePassword);
    this.empEditForm.controls['role'].setValue(data.role);
    this.empEditForm.controls['employeeCompany'].setValue(data.companyName)

  }

  onDeleteEmployee(id: any) {
    this.employeeId = id;
  }


  update() {
    console.log(this.empEditForm.value);
    
    this.apiService.updateEmployee(this.empEditForm.value).subscribe(res => {
      console.log(res);
      if (res !== null) {

        this.getEmployeesList(this.state);
        this.confirmDialogService.confirmThis("Employee Data Updated Successfully!!", function () {  
          
        })
      }
      else {
        this.confirmDialogService.confirmThis("Please choose different username", function () {  
       
        })

      }
    })
  }


  //Employee activation
  activateEmployee(emp:any){
    console.log(emp);
    
    this.apiService.activateEmployees(emp).subscribe(res=>{
      if(res!==null){
        this.getEmployeesList(this.state);
        this.confirmDialogService.confirmThis("Employee activated", function () {  
         
        }) 
      }else{
        this.confirmDialogService.confirmThis("Activate Company first", function () {  
         
        })
      }
    })
  }

  fileDownload() {
    for (let e of this.employeeList) {
      let employee = new EmployeeReport(
        e.employeeId, e.employeeName, e.employeeUserName, e.company.companyName, e.role
      )
      this.EmployeeReportList.push(employee);
    }

    //Headers for CSV file
    let headers = ['Employee Id', 'Employee Name', 'Username', 'Company', 'Role'];

    //HeaderList for iterating the array
    let headerList = ['employeeId', 'employeeName', 'employeeUserName', 'companyName', 'role'];

    this.reportGenerate.downloadFile(this.EmployeeReportList, 'employee list', headers, headerList);
  }
}