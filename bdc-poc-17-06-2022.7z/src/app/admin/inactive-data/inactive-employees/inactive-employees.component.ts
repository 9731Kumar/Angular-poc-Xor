import { Component, OnInit } from '@angular/core';
import { ConfirmDialogService } from 'src/app/confirm-dialog/confirm-dialog.service';
import { EmployeeReport } from 'src/app/modal/employee-report';
import { ApiServiceService } from 'src/app/services/api-service.service';
import { ReportGenerateService } from 'src/app/services/report-generate.service';

@Component({
  selector: 'app-inactive-employees',
  templateUrl: './inactive-employees.component.html',
  styleUrls: ['./inactive-employees.component.css']
})
export class InactiveEmployeesComponent implements OnInit {
  inactiveEmployeeList:any[]=[];
  count:number = 5;
  p:number = 1;
  searchText:any;
  EmployeeDisplayList:EmployeeReport[]=[]

  EmployeeReportList:EmployeeReport[]=[];

  constructor(private apiService:ApiServiceService,  private reportGenerate:ReportGenerateService,private confirmDialogService:ConfirmDialogService) { }

  ngOnInit(): void {
    this.getInactivatedEmployees();
  }

  key:string='id';
  reverse:boolean=false
  Sort(key:any){
   this.key=key;
   this.reverse=!this.reverse;
  }

  getInactivatedEmployees(){
    this.apiService.getInactivatedEmployeeList().subscribe(res=>{
      this.inactiveEmployeeList=res;
      this.EmployeeDisplayList=[]
      for(let e of this.inactiveEmployeeList){
        let employee=new EmployeeReport(
          e.employeeId, e.employeeName, e.employeeUserName,e.company.companyName, e.role
        )
        this.EmployeeDisplayList.push(employee);
      }
    })
  }

  activateEmployee(emp:any){
    console.log(emp);
    
    this.apiService.activateEmployees(emp).subscribe(res=>{
      if(res!==null){
        this.getInactivatedEmployees();
        this.confirmDialogService.confirmThis("Employee activated", function () {  
         
        }) 
      }else{
        this.confirmDialogService.confirmThis("Activate Company first", function () {  
         
        })
      }
    })
  }

  fileDownload(){

    for(let e of this.inactiveEmployeeList){
      let employee=new EmployeeReport(
        e.employeeId, e.employeeName, e.employeeUserName,e.company.companyName, e.role
      )
      this.EmployeeReportList.push(employee);
    }

    //Headers for CSV file
    let headers=['Employee Id','Employee Name', 'Username', 'Company','Role'];

    //HeaderList for iterating the array
    let headerList=['employeeId','employeeName','employeeUserName','companyName','role'];

    this.reportGenerate.downloadFile(this.EmployeeReportList,'employee list',headers,headerList);
  }
}
