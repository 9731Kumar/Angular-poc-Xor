import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InactiveCompaniesComponent } from './inactive-companies.component';

describe('InactiveCompaniesComponent', () => {
  let component: InactiveCompaniesComponent;
  let fixture: ComponentFixture<InactiveCompaniesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InactiveCompaniesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InactiveCompaniesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
