import { Component, OnInit } from '@angular/core';
import { ConfirmDialogService } from 'src/app/confirm-dialog/confirm-dialog.service';
import { ApiServiceService } from 'src/app/services/api-service.service';
import { ReportGenerateService } from 'src/app/services/report-generate.service';

@Component({
  selector: 'app-inactive-companies',
  templateUrl: './inactive-companies.component.html',
  styleUrls: ['./inactive-companies.component.css']
})
export class InactiveCompaniesComponent implements OnInit {
  inactiveCompanyList:any[]=[];
  company:any;
  activateEmployee:boolean=false;
  count:number = 7;
  p:number = 1;
  searchText:any;
  constructor(private apiService:ApiServiceService, private reportGenerate:ReportGenerateService,private confirmDialogService:ConfirmDialogService) { }

  ngOnInit(): void {
    this.getInActiveCompanies();
  }

  key:string='id';
  reverse:boolean=false
  Sort(key:any){
   this.key=key;
   this.reverse=!this.reverse;
  }

  getInActiveCompanies(){
    this.apiService.getInActiveCompaniesList().subscribe(res=>{
      this.inactiveCompanyList=res;
    })
  }

  activeCompanyList(c:any){
    this.company=c;
  }

  activateCompanyWithEmployee(){
    this.activateEmployee=true;
    this.apiService.activateCompany(this.company,this.activateEmployee).subscribe(res=>{
        this.getInActiveCompanies();
        this.confirmDialogService.confirmThis("Company Activated with Employee", function () {  
         
        })
    })

  }

  activateCompanyOnly(){
    this.activateEmployee=false;
    this.apiService.activateCompany(this.company,this.activateEmployee).subscribe(res=>{
        this.getInActiveCompanies();
    })

  }

  fileDownload(){

    //Headers for CSV file
    let headers=['Company Id','Company Name', 'Email', 'Service','Location','Type','Logo'];
    
    //HeaderList for iterating the array
    let headerList=['companyId','companyName','companyEmail','companyService','companyLocation','companyType','logo'];

    this.reportGenerate.downloadFile(this.inactiveCompanyList,'inactive company list',headers,headerList);
  }

}
