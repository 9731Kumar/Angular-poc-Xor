export class EmployeeReport {

    constructor(
        public employeeId:number,
        public employeeName:string,
        public employeeUserName:string,
        public companyName:string,
        public role:string
    ){}
    
}
