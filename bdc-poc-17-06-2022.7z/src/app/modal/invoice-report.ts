export class InvoiceReport {

    public contractID:string;
    public vendor:string;
    public contractApprovedBy:string;
    public id:string;
    public date:Date;
    public invoiceAmount:number;
    public invoiceRaisedBy:string;
    public invoiceReviewedBy:string;
    public invoiceApprovedBy:string;
    public invoicePaymentMadeBy:string;
    public status:string;

    constructor(contractID:string, vendor:string,contractApprovedBy:string,id:string,date:Date,
        invoiceAmount:number, invoiceRaisedBy:string,invoiceReviewedBy:string,invoiceApprovedBy:string,
        invoicePaymentMadeBy:string,status:string){
            this.contractID=contractID;
            this.vendor=vendor;
            this.id=id;
            this.date=date;
            this.invoiceAmount=invoiceAmount;
            this.invoiceRaisedBy=invoiceRaisedBy;
            this.invoiceReviewedBy=invoiceReviewedBy;
            this.invoiceApprovedBy=invoiceApprovedBy;
            this.invoicePaymentMadeBy=invoicePaymentMadeBy;
            this.status=status;
            this.contractApprovedBy=contractApprovedBy;
           

    }

}
