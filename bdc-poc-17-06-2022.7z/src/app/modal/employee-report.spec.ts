import { EmployeeReport } from './employee-report';

describe('EmployeeReport', () => {
  it('should create an instance', () => {
    expect(new EmployeeReport()).toBeTruthy();
  });
});
