export class ContractReport {
    constructor(
        public contractID:string,
        public vendor:string,
        public client:string,
        public contractDate:Date,
        public amount:number,
        public balance:number,
        public status:string
      
    ){}
}
