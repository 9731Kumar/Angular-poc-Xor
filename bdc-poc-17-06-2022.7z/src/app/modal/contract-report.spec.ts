import { ContractReport } from './contract-report';

describe('ContractReport', () => {
  it('should create an instance', () => {
    expect(new ContractReport()).toBeTruthy();
  });
});
