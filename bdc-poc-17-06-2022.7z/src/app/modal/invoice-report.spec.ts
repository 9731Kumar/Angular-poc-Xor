import { InvoiceReport } from './invoice-report';

describe('InvoiceReport', () => {
  it('should create an instance', () => {
    expect(new InvoiceReport()).toBeTruthy();
  });
});
