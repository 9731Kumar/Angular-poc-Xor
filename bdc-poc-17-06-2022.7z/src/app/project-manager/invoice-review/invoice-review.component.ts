import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { InvoiceReport } from 'src/app/modal/invoice-report';
import { ApiServiceService } from 'src/app/services/api-service.service';

@Component({
  selector: 'app-invoice-review',
  templateUrl: './invoice-review.component.html',
  styleUrls: ['./invoice-review.component.css']
})
export class InvoiceReviewComponent implements OnInit {

  pendingInvoices:any
  reviewForm!:FormGroup;

  updateInvoice:any;
  searchText:any;

  count:number = 7;
  p:number = 1;
  pendingReviewDisplayInvoices:any[]=[];
  

  constructor(private apiService:ApiServiceService) { }

  ngOnInit(): void {

    this.getListOfPendingInvoices();
    this.reviewForm=new FormGroup({
      id:new FormControl(''),
      date:new FormControl(''),
      invoiceRaisedBy:new FormControl(''),
      invoiceAmount:new FormControl(''),
      status:new FormControl(''),
      vendor:new FormControl(''),
      contractApprovedBy:new FormControl(''),
      contractID:new FormControl('')
    })
    
  }

  key:string='id';
  reverse:boolean=false
  Sort(key:any){
   this.key=key;
   this.reverse=!this.reverse;
  }
  
  getListOfPendingInvoices(){

    this.apiService.getPendingInvoices(this.apiService.contractId).subscribe(res=>{
      this.pendingInvoices=res;
      this.pendingReviewDisplayInvoices=[]
      for(let inv of this.pendingInvoices){
        let  invoice=new InvoiceReport(
           inv.contract.contractID,inv.contract.vendor,inv.contract.contractApprovedBy, inv.id, inv.date,
           inv.invoiceAmount, inv.invoiceRaisedBy, inv.invoiceReviewedBy,inv.invoiceApprovedBy,'',inv.status
         );
   
         this.pendingReviewDisplayInvoices.push(invoice);
       }
      

})

  }

  onReview(invoice:any){
    console.log(invoice)
   this.updateInvoice=invoice;
   this.reviewForm.controls['id'].setValue(invoice.id);
   this.reviewForm.controls['date'].setValue(invoice.date);
   this.reviewForm.controls['invoiceRaisedBy'].setValue(invoice.invoiceRaisedBy);
   this.reviewForm.controls['invoiceAmount'].setValue(invoice.invoiceAmount);
   this.reviewForm.controls['status'].setValue(invoice.status);
   this.reviewForm.controls['vendor'].setValue(invoice.vendor);
   this.reviewForm.controls['contractApprovedBy'].setValue(invoice.contractApprovedBy);
   this.reviewForm.controls['contractID'].setValue(invoice.contractID);

   //this.reviewInvoice();
  }

  reviewInvoice(){
    // console.log("Update Inovoice ::"+this.updateInvoice);
    // console.log("Update Inovoice ct id ::"+this.updateInvoice.contractID);
 
    this.apiService.reviewInvoice(this.updateInvoice).subscribe(res=>{
      console.log(res);
      
      this.getListOfPendingInvoices();
    })
  }

}

