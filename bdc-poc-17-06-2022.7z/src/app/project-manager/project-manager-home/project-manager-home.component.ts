import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ContractReport } from 'src/app/modal/contract-report';
import { ApiServiceService } from 'src/app/services/api-service.service';
import { ReportGenerateService } from 'src/app/services/report-generate.service';

@Component({
  selector: 'app-project-manager-home',
  templateUrl: './project-manager-home.component.html',
  styleUrls: ['./project-manager-home.component.css']
})
export class ProjectManagerHomeComponent implements OnInit {

  listofcontracts:any[]=[];
  count:number = 5;
  p:number = 1;
  searchText:any;
  aprrovedContractsDisplayList:any[]=[];

  constructor(private apiService:ApiServiceService,private router:Router, private reportGenerate:ReportGenerateService) { }

  ngOnInit(): void {
   
    this.getListOfApprovedContacts();
  
  }

  key:string='id';
  reverse:boolean=false
  Sort(key:any){
   this.key=key;
   this.reverse=!this.reverse;
  }

  getListOfApprovedContacts(){

    this.apiService.getAllApprovedContracts().subscribe(res=>{
    
      this.listofcontracts=res;
      this.aprrovedContractsDisplayList=[]
      for(let contract of this.listofcontracts){
        let  contract1=new ContractReport(
           contract.contractID,contract.vendor,contract.client,contract.contractDate,contract.amount,contract.balance,contract.status
         );
         this.aprrovedContractsDisplayList.push(contract1);
       }
   })
  }

  onSubmit(contract:any){

    console.log(contract);

    this.apiService.contractId=contract.contractID;
    this.router.navigate(['project-dashboard/invoice-review'])
    
  }

  fileDownload(){

    //Headers for CSV file
    let headers=['Contract No','Vendor', 'Client', 'Contract Date','Start Date','End Date','Contract Value','Balance Amount to pay','Status','Description', 'Contract Raised By','Contract Approved By'];

    //HeaderList for iterating the array
    let headerList=['contractID','vendor','client','contractDate','contractStratDate','contractEndDate','amount','balance','status','description','contractRaisedBy','contractApprovedBy'];

    this.reportGenerate.downloadFile(this.listofcontracts,'approved contract list',headers,headerList);
  }

}
