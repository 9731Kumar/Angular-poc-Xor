import { Component, OnInit } from '@angular/core';
import { InvoiceReport } from 'src/app/modal/invoice-report';
import { ApiServiceService } from 'src/app/services/api-service.service';
import { ReportGenerateService } from 'src/app/services/report-generate.service';

@Component({
  selector: 'app-reviewed-invoice-list',
  templateUrl: './reviewed-invoice-list.component.html',
  styleUrls: ['./reviewed-invoice-list.component.css']
})
export class ReviewedInvoiceListComponent implements OnInit {

  
  reviewedInvoices:any[]=[];
  count:number = 7;
  p:number = 1;
  searchText:any;

  dispalyReviewedInvoices:InvoiceReport[]=[];

  InvoiceReportList:InvoiceReport[]=[];

  constructor(private apiService:ApiServiceService, private reportGenerate:ReportGenerateService) { }

  ngOnInit(): void {
    this.getReviewedInvoices();
  }

  key:string='id';
  reverse:boolean=false
  Sort(key:any){
   this.key=key;
   this.reverse=!this.reverse;
  }

  getReviewedInvoices(){
    this.apiService.getReviewedInvoices().subscribe(res=>{
      this.reviewedInvoices=res;
      this.dispalyReviewedInvoices=[]
      for(let inv of this.reviewedInvoices){
        let  invoice=new InvoiceReport(
           inv.contract.contractID,inv.contract.vendor,'', inv.id, inv.date,
           inv.invoiceAmount, inv.invoiceRaisedBy, inv.invoiceReviewedBy,"",'',inv.status
         );
   
         this.dispalyReviewedInvoices.push(invoice);
       }
    })
  }


  fileDownload(){

    for(let inv of this.reviewedInvoices){
      let  invoice=new InvoiceReport(
         inv.contract.contractID,inv.contract.vendor,'', inv.id, inv.date,
         inv.invoiceAmount, inv.invoiceRaisedBy, inv.invoiceReviewedBy,"",'',inv.status
       );
 
       this.InvoiceReportList.push(invoice);
     }

    //Headers for CSV file
    let headers=['Contract No','Vendor', 'Invoice No', 'Invoice Date','Invoice Amount','Invoice Raised By','Invoice Rewived By','Status'];

    //HeaderList for iterating the array
    let headerList=['contractID','vendor','id','date','invoiceAmount','invoiceRaisedBy','invoiceReviewedBy','status'];

    this.reportGenerate.downloadFile(this.InvoiceReportList,'approved invoice list',headers,headerList);
  }

}
