import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReviewedInvoiceListComponent } from './reviewed-invoice-list.component';

describe('ReviewedInvoiceListComponent', () => {
  let component: ReviewedInvoiceListComponent;
  let fixture: ComponentFixture<ReviewedInvoiceListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReviewedInvoiceListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReviewedInvoiceListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
