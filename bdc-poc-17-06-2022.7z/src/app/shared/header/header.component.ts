import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiServiceService } from 'src/app/services/api-service.service';
import { AuthenticateServiceService } from 'src/app/services/authenticate-service.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  userName!:any;
  constructor( public service:AuthenticateServiceService, private router:Router
    , private apiService:ApiServiceService){
      
  }

  ngOnInit(): void {
    this.userName=sessionStorage.getItem('userName');   
  }
  adminSignOut(){
    sessionStorage.removeItem('userName');
    sessionStorage.removeItem('role');
    this.router.navigate(['loginuser'])
  }
}