import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiServiceService } from 'src/app/services/api-service.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  userName:any;
  profileForm!:FormGroup;
  isEditProfile:boolean=false;


  employee:any;

  employeeId:any;
  employeeName:any;
  employeeUserName:any;
  employeePassword:any;
  role:any;
  employeeCompany:any;

  constructor(private router:Router, private apiService:ApiServiceService) {
    
  }

  ngOnInit(): void {
    this.userName=sessionStorage.getItem('userName');
    this.getEmployeeDetails(this.userName);

    this.profileForm=new FormGroup({
      employeeId:new FormControl(''),
      employeeName:new FormControl('',[Validators.required, Validators.minLength(3)]),
      employeeUserName:new FormControl('',[Validators.required, Validators.minLength(4)]),
      employeePassword:new FormControl('',[Validators.required, Validators.minLength(4)]),
      role:new FormControl(''),
      employeeCompany:new FormControl('')
    });
    
  }

  getEmployeeDetails(userName:any){
    this.apiService.getEmployeeByName(userName).subscribe(res=>{
     this.employee=res;
      console.log(this.employee);
      this.employeeId=this.employee.employeeId;
      this.employeeName=this.employee.employeeName;
      this.employeeUserName=this.employee.employeeUserName;
      this.employeePassword=this.employee.employeePassword;
      this.role=this.employee.role;
      this.employeeCompany=this.employee.company.companyName;
    })
  }

  get f(){
    return this.profileForm.controls;
  }

  editProfile(){
    this.isEditProfile=true;
    this.profileForm.controls['employeeId'].setValue(this.employeeId);
    this.profileForm.controls['employeeName'].setValue(this.employeeName);
    this.profileForm.controls['employeeUserName'].setValue(this.employeeUserName);
    this.profileForm.controls['employeePassword'].setValue(this.employeePassword);
    this.profileForm.controls['role'].setValue(this.role);
    this.profileForm.controls['employeeCompany'].setValue(this.employeeCompany);
    
  }


  onSubmit(data:any){
    console.log(this.profileForm.value);
    console.log(data);
    this.apiService.updateEmployee(this.profileForm.value).subscribe(res=>{
      if(res!== null){
      console.log(res);
      alert("Employee Edit successfull")
      sessionStorage.setItem('userName',res.employeeUserName);
      this.getEmployeeDetails(res.employeeUserName);
      this.userName=sessionStorage.getItem('userName');
      this.isEditProfile=false;
      } else{
        alert("Username already exists, Choose different Username")
      }
    })
    
    
  }


  signOut(){
    sessionStorage.removeItem('userName');
    sessionStorage.removeItem('role');
    this.router.navigate(['loginuser']);
  }

}
