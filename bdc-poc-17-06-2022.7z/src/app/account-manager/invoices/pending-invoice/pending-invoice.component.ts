import { Component, OnInit } from '@angular/core';
import { InvoiceReport } from 'src/app/modal/invoice-report';
import { ApiServiceService } from 'src/app/services/api-service.service';
import { ReportGenerateService } from 'src/app/services/report-generate.service';

@Component({
  selector: 'app-pending-invoice',
  templateUrl: './pending-invoice.component.html',
  styleUrls: ['./pending-invoice.component.css']
})
export class PendingInvoiceComponent implements OnInit {

  vendorPendingInvoices: any[] = [];

  count: number = 5;
  p: number = 1;
  searchText:any;
  pendingInvoicesDisplayList:any[]=[]

  InvoiceReportList:InvoiceReport[]=[];

  constructor(private apiService: ApiServiceService, private reportGenerate:ReportGenerateService) { }

  ngOnInit(): void {
    this.getPendingInvoicesVendor();
  }

  key: string = 'id';
  reverse: boolean = false
  Sort(key: any) {
    this.key = key;
    this.reverse = !this.reverse;
  }

  getPendingInvoicesVendor() {
    this.apiService.getPendingInvoicesVendor().subscribe(
      res => {

        this.vendorPendingInvoices = res;
        for(let inv of this.vendorPendingInvoices){
          let  invoice=new InvoiceReport(
             inv.contract.contractID,inv.contract.client,'', inv.id, inv.date,
             inv.invoiceAmount, inv.invoiceRaisedBy, inv.invoiceReviewedBy,inv.invoiceApprovedBy,'',inv.status
           );
     
           this.pendingInvoicesDisplayList.push(invoice);
         }
      }
    )
  }

  fileDownload(){

    for(let inv of this.vendorPendingInvoices){
      let  invoice=new InvoiceReport(
         inv.contract.contractID,inv.contract.vendor,'', inv.id, inv.date,
         inv.invoiceAmount, inv.invoiceRaisedBy, '','','',inv.status
       );
 
       this.InvoiceReportList.push(invoice);
     }

    //Headers for CSV file
    let headers=['Contract No','Vendor', 'Invoice No', 'Invoice Date','Invoice Amount','Invoice Raised By','Status'];

    //HeaderList for iterating the array
    let headerList=['contractID','vendor','id','date','invoiceAmount','invoiceRaisedBy','status'];

    this.reportGenerate.downloadFile(this.InvoiceReportList,'pending invoice list',headers,headerList);
  }

}
