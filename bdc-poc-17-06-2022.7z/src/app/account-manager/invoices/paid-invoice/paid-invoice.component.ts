import { Component, OnInit } from '@angular/core';
import { InvoiceReport } from 'src/app/modal/invoice-report';
import { ApiServiceService } from 'src/app/services/api-service.service';
import { PdfReportService } from 'src/app/services/pdf-report.service';
import { ReportGenerateService } from 'src/app/services/report-generate.service';

@Component({
  selector: 'app-paid-invoice',
  templateUrl: './paid-invoice.component.html',
  styleUrls: ['./paid-invoice.component.css']
})
export class PaidInvoiceComponent implements OnInit {

  paidInvoices:any;
  count:number = 5;
  p:number = 1;
  searchText:any;

  InvoiceList:InvoiceReport[]=[];
  paidInvoicesDisplayList:any[]=[]

  constructor(private apiService:ApiServiceService, private reportGenerate:ReportGenerateService,
    private pdfReport:PdfReportService) { }

  ngOnInit(): void {
    this.getPaidInvoices();
  }

  key:string='id';
  reverse:boolean=false
  Sort(key:any){
   this.key=key;
   this.reverse=!this.reverse;
  }

  getPaidInvoices(){
    this.apiService.getPaidInvoicesForVendor().subscribe(res=>{
      this.paidInvoices=res;
      console.log(this.paidInvoices);
      
      for(let inv of this.paidInvoices){
        let  invoice=new InvoiceReport(
           inv.contract.contractID,inv.contract.vendor,'', inv.id, inv.date,
           inv.invoiceAmount, inv.invoiceRaisedBy, inv.invoiceReviewedBy,inv.invoiceApprovedBy,
            inv.invoicePaymentMadeBy,inv.status
         );
   
         this.paidInvoicesDisplayList.push(invoice);
       }
    })
  }

  downloadInvoice(inv:any){
    let body=[['Contract Id',inv.contractID],['Vendor',inv.vendor],['Invoice Id',inv.id],['Invoice Date',inv.date],
              ['Invoice Amount',inv.invoiceAmount],['Invoice Raised By',inv.invoiceRaisedBy],['Invoice Reviewed By',inv.invoiceReviewedBy],
              ['Invoice Approved By',inv.invoiceApprovedBy],['Invoice Payment By',inv.invoicePaymentMadeBy]]
    let pdfTitle="Invoice Copy";
    let pdfName="invoice_copy"
    this.pdfReport.convert(body,pdfTitle,pdfName);

  }

  fileDownload(){

    for(let inv of this.paidInvoices){
     let  invoice=new InvoiceReport(
        inv.contract.contractID,inv.contract.vendor,'', inv.id, inv.date,
        inv.invoiceAmount, inv.invoiceRaisedBy, inv.invoiceReviewedBy,inv.invoiceApprovedBy,
         inv.invoicePaymentMadeBy,inv.status
      );

      this.InvoiceList.push(invoice);
    }

    //Headers for CSV file
    let headers=['Contract No','Vendor', 'Invoice No', 'Invoice Date','Invoice Amount','Invoice Raised By','Invoice Rewived By','Invoice Approved By','Payment By','Status'];

    //HeaderList for iterating the array
    let headerList=['contractID','vendor','id','date','invoiceAmount','invoiceRaisedBy','invoiceReviewedBy','invoiceApprovedBy','invoicePaymentMadeBy','status'];

    this.reportGenerate.downloadFile(this.InvoiceList,'approved invoice list',headers,headerList);
  }

}
