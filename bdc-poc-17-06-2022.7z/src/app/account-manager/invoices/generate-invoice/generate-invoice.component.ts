import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ConfirmDialogService } from 'src/app/confirm-dialog/confirm-dialog.service';
import { ApiServiceService } from 'src/app/services/api-service.service';

@Component({
  selector: 'app-generate-invoice',
  templateUrl: './generate-invoice.component.html',
  styleUrls: ['./generate-invoice.component.css']
})
export class GenerateInvoiceComponent implements OnInit {
  contractData:any;
  inVoiceForm!: FormGroup;
  contractID:any;
  contractRaisedBy:any;
  client:any;
  contractDate:any;
  amount:any;
  invoiceRaisedBy:any;
  balance:any;

  isInvoiceAmountLessThanBalance:boolean=false;
  btnDisable:boolean=true;
  
  constructor(private apiService:ApiServiceService,private router:Router,private confirmDialogService:ConfirmDialogService) { }

  ngOnInit(): void {

   

    this.contractData=this.apiService.approvedContracts;
    //console.log(this.contractData);
    
    this.contractID=this.contractData.contractID;
    this.client=this.contractData.client;
    this.contractRaisedBy=this.contractData.contractRaisedBy;
    this.contractDate=this.contractData.contractDate;
    this.amount=this.contractData.amount;
    this.balance=this.contractData.balance;

    this.getEmployeeName();

    this.inVoiceForm = new FormGroup({
      contractID: new FormControl(this.contractID),
      client: new FormControl(this.client),
      contractRaisedBy: new FormControl(this.contractRaisedBy),
      amount: new FormControl(this.amount),
      invoiceAmount: new FormControl('',[Validators.required,Validators.max(this.balance)]),
      contractDate:new FormControl(this.contractDate),
      invoiceRaisedBy:new FormControl(this.invoiceRaisedBy),
      balance:new FormControl(this.balance)

    })
    
  }

  getEmployeeName(){
    let username=sessionStorage.getItem('userName')
    this.apiService.getEmployeeByName(username).subscribe(res=>{
      this.invoiceRaisedBy=res.employeeName;
    })
  }

  get f(){
    return this.inVoiceForm.controls;
  }

  checkInvoiceAmount(event:Event){
    let value=Number((event.target as HTMLInputElement ).value);
    //console.log(value); 
      if(value>this.balance){
       this.isInvoiceAmountLessThanBalance=true;
       this.btnDisable=true;
      }else{
        this.isInvoiceAmountLessThanBalance=false;
        this.btnDisable=false;
      }
      

  }


  onSubmit(){
   this.apiService.saveInvoice(this.inVoiceForm.value).subscribe(res=>{
   
    alert("Invoice Generate Successfully Collect Your Invoice ID @"+res.id)
    this.router.navigate(['account-dashboard/home'])
   })
    
  }

}

