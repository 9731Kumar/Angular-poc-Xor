import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-closed-invoice',
  templateUrl: './closed-invoice.component.html',
  styleUrls: ['./closed-invoice.component.css']
})
export class ClosedInvoiceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
