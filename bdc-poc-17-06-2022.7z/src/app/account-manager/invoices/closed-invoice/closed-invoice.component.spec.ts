import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClosedInvoiceComponent } from './closed-invoice.component';

describe('ClosedInvoiceComponent', () => {
  let component: ClosedInvoiceComponent;
  let fixture: ComponentFixture<ClosedInvoiceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClosedInvoiceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClosedInvoiceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
