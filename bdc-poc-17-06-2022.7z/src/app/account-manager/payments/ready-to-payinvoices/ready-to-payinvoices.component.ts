import { Component, OnInit } from '@angular/core';
import { ConfirmDialogService } from 'src/app/confirm-dialog/confirm-dialog.service';
import { ContractReport } from 'src/app/modal/contract-report';
import { InvoiceReport } from 'src/app/modal/invoice-report';
import { ApiServiceService } from 'src/app/services/api-service.service';
import { ReportGenerateService } from 'src/app/services/report-generate.service';

@Component({
  selector: 'app-ready-to-payinvoices',
  templateUrl: './ready-to-payinvoices.component.html',
  styleUrls: ['./ready-to-payinvoices.component.css']
})
export class ReadyToPayinvoicesComponent implements OnInit {

  
  invoiceList:any[]=[];

  paidInvoice:any;
  count:number = 7;
  p:number = 1;
  searchText:any;

  InvoiceReportList:InvoiceReport[]=[];
  readyToPayDisplayInvoices:any[]=[];

  constructor(private apiService:ApiServiceService, private reportGenerate:ReportGenerateService,private confirmDialogService:ConfirmDialogService) { }

  ngOnInit(): void {
    this.getReadyToPayInvoices();
  }

  key:string='id';
  reverse:boolean=false
  Sort(key:any){
   this.key=key;
   this.reverse=!this.reverse;
  }

  getReadyToPayInvoices(){
    this.readyToPayDisplayInvoices=[]
    this.apiService.getReadyToPayInvoices().subscribe(res=>{
      console.log(res);
      
      this.invoiceList=res;
      for(let inv of this.invoiceList){
        let  invoice=new InvoiceReport(
           inv.contract.contractID,inv.contract.vendor,'', inv.id, inv.date,
           inv.invoiceAmount, inv.invoiceRaisedBy, inv.invoiceReviewedBy,inv.invoiceApprovedBy,'',inv.status
         );
   
         this.readyToPayDisplayInvoices.push(invoice);
       }
      
    })
   // console.log(this.readyToPayDisplayInvoices);
    
  }

  onPaid(data:any){
    this.paidInvoice=data;
  }

  onSubmit(){
    console.log(this.paidInvoice);
    this.apiService.doPayment(this.paidInvoice).subscribe(res=>{
      if(res !==null){
        
        this.getReadyToPayInvoices();
      }else{
        this.confirmDialogService.confirmThis("Server Error", function () {  
         
        })
      }
    })
    
    
  }

  fileDownload(){
    for(let inv of this.invoiceList){
      let  invoice=new InvoiceReport(
         inv.contract.contractID,inv.contract.vendor,'', inv.id, inv.date,
         inv.invoiceAmount, inv.invoiceRaisedBy, inv.invoiceReviewedBy,inv.invoiceApprovedBy,'',inv.status
       );
 
       this.InvoiceReportList.push(invoice);
     }

    //Headers for CSV file
    let headers=['Contract No','Vendor', 'Invoice No', 'Invoice Date','Invoice Amount','Invoice Raised By','Invoice Rewived By','Invoice Approved By','Status'];

    //HeaderList for iterating the array
    let headerList=['contractID','vendor','id','date','invoiceAmount','invoiceRaisedBy','invoiceReviewedBy','invoiceApprovedBy','status'];

    this.reportGenerate.downloadFile(this.InvoiceReportList,'approved invoice list',headers,headerList);
  }

}
