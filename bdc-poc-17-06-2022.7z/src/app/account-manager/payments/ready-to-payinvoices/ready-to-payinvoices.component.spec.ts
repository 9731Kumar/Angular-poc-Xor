import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReadyToPayinvoicesComponent } from './ready-to-payinvoices.component';

describe('ReadyToPayinvoicesComponent', () => {
  let component: ReadyToPayinvoicesComponent;
  let fixture: ComponentFixture<ReadyToPayinvoicesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReadyToPayinvoicesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReadyToPayinvoicesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
