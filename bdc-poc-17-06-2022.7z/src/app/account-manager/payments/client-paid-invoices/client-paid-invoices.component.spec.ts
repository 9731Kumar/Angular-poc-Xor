import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClientPaidInvoicesComponent } from './client-paid-invoices.component';

describe('ClientPaidInvoicesComponent', () => {
  let component: ClientPaidInvoicesComponent;
  let fixture: ComponentFixture<ClientPaidInvoicesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClientPaidInvoicesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClientPaidInvoicesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
