import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ContractReport } from 'src/app/modal/contract-report';
import { ApiServiceService } from 'src/app/services/api-service.service';

@Component({
  selector: 'app-acc-home',
  templateUrl: './acc-home.component.html',
  styleUrls: ['./acc-home.component.css']
})
export class AccHomeComponent implements OnInit {
  count:number = 5;
  p:number = 1;
  searchText:any;
  
  approvedContractList:any[]=[];
  aprrovedContractsDisplayList:any[]=[]

  constructor(private apiService:ApiServiceService,private router:Router) { }

  ngOnInit(): void {
    this.apiService.getAllApprovedContractsForVendor().subscribe(res=>{
    
      this.approvedContractList=res;
      for(let contract of this.approvedContractList){
        let  contract1=new ContractReport(
           contract.contractID,contract.vendor,contract.client,contract.contractDate,contract.amount,contract.balance,contract.status
         );
         this.aprrovedContractsDisplayList.push(contract1);
       }

   })
  
  }

  key:string='id';
  reverse:boolean=false
  Sort(key:any){
   this.key=key;
   this.reverse=!this.reverse;
  }


  onSubmit(contract:any){

    console.log(contract);
    
    this.apiService.approvedContracts=contract;
    this.router.navigate(['account-dashboard/generate-invoice']);
    
  }

}
