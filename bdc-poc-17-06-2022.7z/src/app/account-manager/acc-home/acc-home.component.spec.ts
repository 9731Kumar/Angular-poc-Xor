import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AccHomeComponent } from './acc-home.component';

describe('AccHomeComponent', () => {
  let component: AccHomeComponent;
  let fixture: ComponentFixture<AccHomeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AccHomeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AccHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
