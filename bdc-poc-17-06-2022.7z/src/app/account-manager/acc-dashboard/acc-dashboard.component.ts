import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-acc-dashboard',
  templateUrl: './acc-dashboard.component.html',
  styleUrls: ['./acc-dashboard.component.css']
})
export class AccDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
