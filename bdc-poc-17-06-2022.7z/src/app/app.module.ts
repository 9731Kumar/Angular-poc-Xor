import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule,routingComponent } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginUserComponent } from './login-user/login-user.component';
import { SidebarComponent } from './shared/sidebar/sidebar.component';
import { HttpClientModule } from '@angular/common/http';
import { HeaderComponent } from './shared/header/header.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { OrderModule } from 'ngx-order-pipe';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { ProfileComponent } from './shared/profile/profile.component';
import { ContractCreationByFileComponent } from './contract-manager/contract-creation/contract-creation-by-file/contract-creation-by-file.component';
import { ClientApprovedContractsListComponent } from './contract-manager/client-approved-contracts-list/client-approved-contracts-list.component';
import { ConfirmDialogComponent } from './confirm-dialog/confirm-dialog/confirm-dialog.component';
import { ConfirmDialogService } from './confirm-dialog/confirm-dialog.service';

@NgModule({
  declarations: [
    AppComponent,
    LoginUserComponent,
    SidebarComponent,
    routingComponent,
    HeaderComponent,
    ProfileComponent,
    ContractCreationByFileComponent,
    ClientApprovedContractsListComponent,
    ConfirmDialogComponent
   ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    NgxPaginationModule,
    OrderModule,
    Ng2SearchPipeModule,
    FormsModule,
  ],
  exports: [  
    ConfirmDialogComponent  
], 
providers: [ ConfirmDialogService  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
