import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map } from 'rxjs';
import { baseUrl } from './shared-service.service';

@Injectable({
  providedIn: 'root'
})
export class ApiServiceService {

  name: any;
  companyName:any;

  approvedContracts: any;
  contractId: any;
  invoiceReview: any;

  constructor(private httpClient: HttpClient) { }


  saveCompany(obj: any) {
    //let img=obj.logo;
    console.log(obj.logo);
    console.log(typeof obj.logo);
    
    
    return this.httpClient.post<any>(`${baseUrl}/addcompany`, obj)
  }

  getCompanies() {
    return this.httpClient.get<any>(`${baseUrl}/companynames`)
  }


  saveEmployee(obj: any) {

    return this.httpClient.post<any>(`${baseUrl}/addemployee`, obj)
  }


  validateManager(username: string, password: string, role: string) {
    return this.httpClient.get<boolean>(`${baseUrl}/login/${username}/${password}/${role}`);
  }

  getVendorName(userName: string) {

    return this.httpClient.get<string>(`${baseUrl}/getVendor/${userName}`);
  }


  getClients() {
    return this.httpClient.get<any>(`${baseUrl}/getClients`);
  }

  getEmployeeByName(data: any) {
    return this.httpClient.get<any>(`${baseUrl}/getEmployeeByName/${data}`);
  }


  createContract(obj: any) {
    let username = sessionStorage.getItem('userName')
    return this.httpClient.post<any>(`${baseUrl}/addcontract/${username}`, obj)
  }

  getAllPendingContracts(data: any) {
    let username = sessionStorage.getItem('userName')
    return this.httpClient.get<any>(`${baseUrl}/getPendingContracts/${username}`)
  }


  getContractAprove(data: any) {
    let username = sessionStorage.getItem('userName')
    return this.httpClient.put<any>(`${baseUrl}/contractApprove/${username}`, data)

  }

  //fetching the company list( here we passing the active and inactive)
  getCompanyList(value:string) {
    return this.httpClient.get<any>(`${baseUrl}/companies/${value}`)
  }

  // Fetching Employee List (here we passing the active or inactive)
  getEmployeeList(value:string) {
    return this.httpClient.get<any>(`${baseUrl}/employees/${value}`);
  }

  //delete the employee record by its id

  deleteEmployee(id: any) {
    return this.httpClient.delete<any>(`${baseUrl}/deleteEmployee/${id}`)
  }

  //deleting the company by its id

  deleteCompany(id: any) {
    return this.httpClient.delete<any>(`${baseUrl}/deleteCompany/${id}`)
  }

  getAllApprovedContracts() {
    let username = sessionStorage.getItem('userName')
    return this.httpClient.get<any>(`${baseUrl}/getApprovedContracts/${username}`)
  }

  getVendorPendingContracts() {
    let username = sessionStorage.getItem('userName')
    return this.httpClient.get<any>(`${baseUrl}/getVendorPendingContracts/${username}`)
  }

  getAllApprovedContractsForVendor() {
    let username = sessionStorage.getItem('userName')
    return this.httpClient.get<any>(`${baseUrl}/getApprovedContractsVendor/${username}`)
  }

  saveInvoice(obj: any) {

    let username = sessionStorage.getItem('userName')
    return this.httpClient.post<any>(`${baseUrl}/createInvoice/${username}`, obj)
  }


  getPendingInvoices(id: any) {

    let username = sessionStorage.getItem('userName')
    return this.httpClient.get<any>(`${baseUrl}/getPendingInvoices/${username}/${id}`)
  }

  reviewInvoice(data: any) {
    let username = sessionStorage.getItem('userName');
    return this.httpClient.put<any>(`${baseUrl}/reviewInvoice/${username}`, data);
  }

  getReviewedInvoices() {

    let username = sessionStorage.getItem('userName')
    return this.httpClient.get<any>(`${baseUrl}/getReviewedInvoices/${username}`)
  }

  getApprovalPendingInvoices() {

    let username = sessionStorage.getItem('userName')
    return this.httpClient.get<any>(`${baseUrl}/getReviewedInvoicesForApproval/${username}`)
  }

  approveInvoice(obj: any) {

    let username = sessionStorage.getItem('userName')
    return this.httpClient.put<any>(`${baseUrl}/approveInvoice/${username}`, obj)
  }

  getApprovedInvoices() {

    let username = sessionStorage.getItem('userName')
    return this.httpClient.get<any>(`${baseUrl}/getApprovedInvoices/${username}`)
  }

  getPendingInvoicesVendor() {

    let username = sessionStorage.getItem('userName')
    return this.httpClient.get<any>(`${baseUrl}/getPendingInvoicesVendor/${username}`)
  }

  getReadyToPayInvoices() {
    let username = sessionStorage.getItem('userName')
    return this.httpClient.get<any>(`${baseUrl}/getReadyToPayInvoiceForClient/${username}`)
  }

  doPayment(obj: any) {
    let username = sessionStorage.getItem('userName');
    return this.httpClient.put<any>(`${baseUrl}/paymentSuccess/${username}`, obj)
  }

  getPaidInvoices() {
    let username = sessionStorage.getItem('userName');
    return this.httpClient.get<any>(`${baseUrl}/getPaidInvoice/${username}`)
  }

  getInactivatedEmployeeList() {
    return this.httpClient.get<any>(`${baseUrl}/getInactivateEmployees`);
  }

  getInActiveCompaniesList() {
    return this.httpClient.get<any>(`${baseUrl}/getInactivateCompany`);
  }

  activateEmployees(employee: any) {
    return this.httpClient.put<any>(`${baseUrl}/activateEmployee`, employee);
  }

  activateCompany(company: any, activateEmployee: boolean) {
    return this.httpClient.put<any>(`${baseUrl}/activateCompany/${activateEmployee}`, company);
  }
  getAllCompanies() {
    return this.httpClient.get<any>(`${baseUrl}/companies`)
  }

  getAllEmployees() {
    return this.httpClient.get<any>(`${baseUrl}/employees`)
  }

  updateCompany(obj:any){
    return this.httpClient.put<any>(`${baseUrl}/edit/company`, obj)
  }

  updateEmployee(obj:any){
    return this.httpClient.put<any>(`${baseUrl}/edit/employee`, obj)
  }

  getRaisedContractsForUser(){
    let username = sessionStorage.getItem('userName');
    return this.httpClient.get<any>(`${baseUrl}/contracts/${username}`)
  }

  getApprovedInvoicesForUser(){
    let username = sessionStorage.getItem('userName');
    return this.httpClient.get<any>(`${baseUrl}/invoices/${username}`)
  }

  saveManyEmp(obj:any[]) {

    console.log("hello::::"+obj);
    
    let username = sessionStorage.getItem('userName')
    return this.httpClient.post<any>(`${baseUrl}/savemanyemp`, obj)
  }

  getPaidInvoicesForVendor(){
    let username = sessionStorage.getItem('userName');
    return this.httpClient.get<any>(`${baseUrl}/vendor/paidInvoice/${username}`)
  }




}
