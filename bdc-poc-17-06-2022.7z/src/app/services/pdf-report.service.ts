import { Injectable } from '@angular/core';
import { auto } from '@popperjs/core';
import jsPDF from 'jspdf';
import 'jspdf-autotable'

@Injectable({
  providedIn: 'root'
})
export class PdfReportService {

  constructor() { }

  test = [['Details', 'Values']]

  addFooter(doc: any) {
    var totalPages = doc.internal.getNumberOfPages();

    for (let i = 1; i <= totalPages; i++) {
      doc.setPage(i);
      //doc.addImage(imgData, 'PNG', 40, 40, 75, 75);
      doc.setTextColor(150);
      doc.setFontSize(10)
      doc.text(10, doc.internal.pageSize.height - 5, 'This is system generated file. No need of signature');
    }

    return doc;
  }


  convert(body: any, pdfTitle: any, pdfName: any) {
    var pdf = new jsPDF();
    pdf.setFontSize(30)
    pdf.setTextColor(38, 0, 255);
    pdf.setFont("Times-Roman","bold");
    //pdf.addFont('ArialMS', 'Arial', 'italic');
    pdf.text(pdfTitle, 61, 25);

    

    (pdf as any).autoTable({

      head: this.test,
      body: body,
      theme:'grid',
      tableWidth: auto,
      margin: { right: 20, left: 20, top: 40 },
      styles: {
        overflow: 'linebreak',
        cellWidth: 'wrap',
        fontSize: 12,
        cellPadding: 4,
        overflowColumns: 'linebreak'
      }
    })

    
    pdf.addImage('../../../assets/images/logo3.png', 'png', 10, 10, 20, 20);
    
    


    //watermark text
    pdf.setTextColor(0,0,0, 0.3);
    pdf.setFontSize(50)
    pdf.text("My Pay", 70, pdf.internal.pageSize.height - 150, {angle: 45, });
    // pdf.text("My Payment Application",10,10);

    pdf = this.addFooter(pdf);

    pdf.save(pdfName + '.pdf')
  }
}
