import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthenticateServiceService {

  totalEmployees: number=0;

  constructor() { }

  isAdminLogin() {
    let role = sessionStorage.getItem('role');
    if (role === 'ADMIN') {
      return true;
    }
    return false;
  }

  isContractManagerLogin() {
    let role = sessionStorage.getItem('role');
    if (role === 'CONTRACTMANAGER') {
      return true;
    }
    return false;
  }

  isUserLogin(){
    let role = sessionStorage.getItem('role');
    return role != null;
  }
}
