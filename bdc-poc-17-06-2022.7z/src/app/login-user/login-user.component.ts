import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiServiceService } from '../services/api-service.service';

@Component({
  selector: 'app-login-user',
  templateUrl: './login-user.component.html',
  styleUrls: ['./login-user.component.css']
})
export class LoginUserComponent implements OnInit {
  userRole = ['Admin', 'Contract Manager', 'Program Manager', 'Account Manager'];
  loginForm!: FormGroup;
  invalidLogin: boolean = false;
  constructor(private router: Router, private apiService: ApiServiceService) { }

  ngOnInit(): void {
    this.loginForm = new FormGroup({
      userName: new FormControl('', Validators.required),
      password: new FormControl('', Validators.required),
      role: new FormControl('')
    })

    sessionStorage.removeItem('userName');
    sessionStorage.removeItem('role');
  }

  get f() {
    return this.loginForm.controls;
  }

  onSubmit() {
    //console.log(this.loginForm.value)
    if (this.loginForm.value.role === 'ADMIN' && this.loginForm.value.userName === 'admin' &&
    this.loginForm.value.password === '1234') {

      sessionStorage.setItem('userName', 'admin');
      sessionStorage.setItem('role', 'ADMIN');
      this.router.navigate(['admin-home/admindashboard'])
      this.invalidLogin = false;
      console.log("Admin Logged in");

    } else if (this.loginForm.value.role === 'CONTRACTMANAGER') {
      console.log("contract manager Logged in");
      let role = this.loginForm.value.role
      let username = this.loginForm.value.userName;
      let password = this.loginForm.value.password;

      
      this.apiService.validateManager(username, password, role).subscribe(res => {
        if (res) {
          sessionStorage.setItem('userName', username);
          sessionStorage.setItem('role', 'CONTRACTMANAGER');
          this.router.navigate(['contract-home/contract-dashboard']);
        } else {
          this.invalidLogin = true;
          this.loginForm.reset();
        }
      })

    } else if (this.loginForm.value.role === 'PROJECTMANAGER') {
      console.log("project manager Logged in");

      let role = this.loginForm.value.role
      let username = this.loginForm.value.userName;
      let password = this.loginForm.value.password;

      this.apiService.validateManager(username, password, role).subscribe(res => {
        if (res) {
          sessionStorage.setItem('userName', username);
          sessionStorage.setItem('role', 'PROJECTMANAGER');
          this.router.navigate(['project-dashboard/home']);
        } else {
          this.invalidLogin = true;
          this.loginForm.reset();
        }
      })

    } else if (this.loginForm.value.role === 'ACCOUNTANTMANAGER') {
      console.log("accountant manager Logged in");

      let role = this.loginForm.value.role
      let username = this.loginForm.value.userName;
      let password = this.loginForm.value.password;

      this.apiService.validateManager(username, password, role).subscribe(res => {
        if (res) {
          sessionStorage.setItem('userName', username);
          sessionStorage.setItem('role', 'ACCOUNTANTMANAGER');
          this.router.navigate(['account-dashboard/home']);
        } else {
          this.invalidLogin = true;
          this.loginForm.reset();
        }
      })
    } else {
      this.invalidLogin = true;
    }
  }
}