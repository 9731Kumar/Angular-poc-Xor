import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ContractApprovedComponent } from './contract-approved.component';

describe('ContractApprovedComponent', () => {
  let component: ContractApprovedComponent;
  let fixture: ComponentFixture<ContractApprovedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ContractApprovedComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ContractApprovedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
