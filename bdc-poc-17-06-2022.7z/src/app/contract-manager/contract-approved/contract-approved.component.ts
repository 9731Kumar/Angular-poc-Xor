import { Component, OnInit } from '@angular/core';
import { ApiServiceService } from 'src/app/services/api-service.service';
import { PdfReportService } from 'src/app/services/pdf-report.service';
import { ReportGenerateService } from 'src/app/services/report-generate.service';

@Component({
  selector: 'app-contract-approved',
  templateUrl: './contract-approved.component.html',
  styleUrls: ['./contract-approved.component.css']
})
export class ContractApprovedComponent implements OnInit {

  approvedContracts:any[]=[];
  count:number = 5;
  p:number = 1;

  searchText:any;

  constructor(private apiService:ApiServiceService,
    private reportGenerate:ReportGenerateService,
    private pdfReport:PdfReportService) { }

  ngOnInit(): void {
    this.getAllApprovedCOntracts();
  }

  key:string='id';
  reverse:boolean=false
  Sort(key:any){
   this.key=key;
   this.reverse=!this.reverse;
  }

  getAllApprovedCOntracts(){
    this.apiService.getAllApprovedContracts().subscribe(res=>
      {
        this.approvedContracts=res;
      })
  }

  fileDownload(){

    //Headers for CSV file
    let headers=['Contract No','Vendor', 'Client', 'Contract Date','Start Date','End Date','Contract Value','Status','Description', 'Contract Raised By','Contract Approved By'];

    //HeaderList for iterating the array
    let headerList=['contractID','vendor','client','contractDate','contractStratDate','contractEndDate','amount','status','description','contractRaisedBy','contractApprovedBy'];

    this.reportGenerate.downloadFile(this.approvedContracts,'approved contract list',headers,headerList);
  }

  downloadContract(contract:any){
    let body=[['Contract Id',contract.contractID],['Vendor',contract.vendor],['Client',contract.client],
              ['Contract Date',contract.contractDate],['Contract Start Date',contract.contractStratDate],['Contract End Date',contract.contractEndDate],
              ['Contract Amount',contract.amount],['Contract Status',contract.status],['Description',contract.description],
              ['Contract Raised By',contract.contractRaisedBy],['Contract Approved By',contract.contractApprovedBy]]
    let pdfTitle="Contract Copy";
    let pdfName="contract_copy"
    this.pdfReport.convert(body,pdfTitle,pdfName);

  }


}
