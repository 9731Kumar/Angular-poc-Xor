import { Component, OnInit } from '@angular/core';
import { InvoiceReport } from 'src/app/modal/invoice-report';
import { ApiServiceService } from 'src/app/services/api-service.service';

@Component({
  selector: 'app-approval-pending-invoice',
  templateUrl: './approval-pending-invoice.component.html',
  styleUrls: ['./approval-pending-invoice.component.css']
})
export class ApprovalPendingInvoiceComponent implements OnInit {

reviwedInvoices:any[]=[];
invoiceData:any;
count:number = 5;
  p:number = 1;
  searchText:any;

reviwedDisplayInvoices:InvoiceReport[]=[];

constructor(private apiService:ApiServiceService) { }

ngOnInit(): void {
  this.getApprovalPendingInvoices();
}

key:string='id';
reverse:boolean=false
Sort(key:any){
 this.key=key;
 this.reverse=!this.reverse;
}

getApprovalPendingInvoices(){
  this.apiService.getApprovalPendingInvoices().subscribe(res=>{
    this.reviwedInvoices=res;
    this.reviwedDisplayInvoices=[]
    for(let inv of this.reviwedInvoices){
      let  invoice=new InvoiceReport(
         inv.contract.contractID,inv.contract.vendor,'', inv.id, inv.date,
         inv.invoiceAmount, inv.invoiceRaisedBy, inv.invoiceReviewedBy,inv.invoiceApprovedBy,'',inv.status
       );
 
       this.reviwedDisplayInvoices.push(invoice);
     }
  })
}

onApprove(invoice:any){

  this.invoiceData=invoice;
  
}

onSubmit(){

  this.apiService.approveInvoice(this.invoiceData).subscribe(res=>{
    console.log(res);
    this.getApprovalPendingInvoices();
    
  })
  


}
}
