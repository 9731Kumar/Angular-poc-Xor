import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ApprovalPendingInvoiceComponent } from './approval-pending-invoice.component';

describe('ApprovalPendingInvoiceComponent', () => {
  let component: ApprovalPendingInvoiceComponent;
  let fixture: ComponentFixture<ApprovalPendingInvoiceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ApprovalPendingInvoiceComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ApprovalPendingInvoiceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
