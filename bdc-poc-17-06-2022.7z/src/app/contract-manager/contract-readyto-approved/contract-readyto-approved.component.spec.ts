import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ContractReadytoApprovedComponent } from './contract-readyto-approved.component';

describe('ContractReadytoApprovedComponent', () => {
  let component: ContractReadytoApprovedComponent;
  let fixture: ComponentFixture<ContractReadytoApprovedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ContractReadytoApprovedComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ContractReadytoApprovedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
