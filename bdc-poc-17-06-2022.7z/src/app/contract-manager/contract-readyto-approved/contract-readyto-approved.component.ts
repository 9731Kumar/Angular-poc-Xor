import { Component, OnInit } from '@angular/core';
import { ConfirmDialogService } from 'src/app/confirm-dialog/confirm-dialog.service';
import { ApiServiceService } from 'src/app/services/api-service.service';

@Component({
  selector: 'app-contract-readyto-approved',
  templateUrl: './contract-readyto-approved.component.html',
  styleUrls: ['./contract-readyto-approved.component.css']
})
export class ContractReadytoApprovedComponent implements OnInit {
  pendingContracts:any[]=[];
  count:number = 5;
  p:number = 1;

  searchText:any;
  
  constructor(private apiservice:ApiServiceService,private confirmDialogService:ConfirmDialogService) { }

  ngOnInit(): void {
   this.getPendingContracts();
  }

  key:string='id';
  reverse:boolean=false
  Sort(key:any){
   this.key=key;
   this.reverse=!this.reverse;
  }
  getPendingContracts(){
    this.apiservice.getAllPendingContracts('kumar123').subscribe(res=>{
      this.pendingContracts=res;
      console.log(res)

    })
  }

  onApprove(contract:any){

    console.log(contract);
    this.apiservice.getContractAprove(contract).subscribe(res=>{
      if(res){
        this.confirmDialogService.confirmThis("Contracts approved", function () {  
         
        })
        this.getPendingContracts();
      }
      else{
        this.confirmDialogService.confirmThis("Contracts not approved", function () {  
         
        })
      }

    })
  }

}

