import { DatePipe } from '@angular/common';
import { Component, OnInit, ViewChild } from '@angular/core';
import { AbstractControl, FormControl, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { ConfirmDialogService } from 'src/app/confirm-dialog/confirm-dialog.service';
import { ApiServiceService } from 'src/app/services/api-service.service';
import { ContractRecord } from './ContractRecord';

@Component({
  selector: 'app-contract-creation',
  templateUrl: './contract-creation.component.html',
  styleUrls: ['./contract-creation.component.css']
})
export class ContractCreationComponent implements OnInit {

  contractCreationForm!: FormGroup;

  employeeName: any;
  vendorName: any;
  username: any;
  clientList: any;
  uploadFile: boolean = false;
  contractCsvCopy: ContractRecord[] = [];
  startDate: any;
  csvStartDate!: Date;

  contractFile!: ContractRecord;



  constructor(private apiService: ApiServiceService,private confirmDialogService:ConfirmDialogService) { }

  ngOnInit(): void {
    this.getEmployee()
    // this.apiService.getClients().subscribe(res => {
    //   this.clientList = res;
    // })
    this.getAllClientList();

    if (this.uploadFile) {

    } if (!this.uploadFile) {
      this.contractCreationForm = new FormGroup({
        vendor: new FormControl(this.vendorName),
        client: new FormControl('', [Validators.required]),
        contractStratDate: new FormControl('', [Validators.required, this.checkFromDate]),
        contractEndDate: new FormControl('', [Validators.required, this.checkToDate]),
        amount: new FormControl('', [Validators.required]),
        description: new FormControl('', [Validators.required]),
        contractRaisedBy: new FormControl(this.employeeName)
      })
    }
  }
  getEmployee() {
    let name = sessionStorage.getItem('userName')
    this.apiService.getEmployeeByName(name).subscribe(res => {

      this.employeeName = res.employeeName;
      this.vendorName = res.company.companyName;
      console.log(this.employeeName);
      console.log(this.vendorName);

    })
  }

  getAllClientList(){
    this.apiService.getCompanies().subscribe(res=>{
      let index=res.indexOf(this.vendorName);
      res.splice(index,1);
      this.clientList=res;
      console.log(this.clientList);
      
      
    })
  }

  getUploadFileContract() {

    this.contractCreationForm = new FormGroup({
      vendor: new FormControl(this.vendorName),
      client: new FormControl(this.contractFile.client),
      contractStratDate: new FormControl(this.contractCsvCopy[0].contractStratDate),
      contractEndDate: new FormControl(this.contractCsvCopy[0].contractEndDate),
      amount: new FormControl(this.contractFile.amount),
      description: new FormControl(this.contractFile.description),
      contractRaisedBy: new FormControl(this.employeeName)
    })
    this.uploadFile = true;
  }



  get f() {
    return this.contractCreationForm.controls;
  }

  onSubmit() {
    console.log(this.contractCreationForm.value);
    if (!this.uploadFile) {
      this.apiService.createContract(this.contractCreationForm.value).subscribe(res => {

        console.log(res)
        this.confirmDialogService.confirmThis("Please Collect the Contract ID for further Reference @ " + res.contractID, function () {  
          //alert("Yes clicked");  
        }) 
        // alert("Please Collect the Contract ID for further Reference @ " + res.contractID)
        this.contractCreationForm.reset();
        window.location.reload();

      })
    }
    else {
      // this.csvStartDate=new Date(this.contractCreationForm.value.contractStratDate);
      let contract=new ContractRecord();
     
      
      contract.contractStratDate=new Date(this.contractCreationForm.value.contractStratDate);
      contract.contractEndDate=new Date(this.contractCreationForm.value.contractEndDate);
      contract.client=this.contractCreationForm.value.client;
      contract.vendor=this.contractCreationForm.value.vendor;
      contract.amount=this.contractCreationForm.value.amount;
      contract.description=this.contractCreationForm.value.description;
      console.log("Date Convertion:::>>>"+contract.contractEndDate);
      
      this.apiService.createContract(contract).subscribe(res => {

        console.log(res)
        alert("Please Collect the Contract ID for further Reference @ " + res.contractID)
        this.contractCreationForm.reset();
        window.location.reload();

      })

    }
  }

  checkFromDate(control: FormControl) {
    let today = new Date();
    today.setHours(0, 0, 0, 0)
    var startDate = new Date(control.value);

    if (startDate < today) {
      return { checkFromDate: true }
    } else {
      return null;
    }

  }

  checkToDate(control: FormControl) {
    let today = new Date();
    today.setHours(0, 0, 0, 0)

    let endDate = new Date(control.value);
    if (endDate < today) {
      return { checkToDate: true };
    } else {
      return null;
    }
  }



  // Reading Contract CSV

  title = 'Angular7-readCSV';

  public records: any[] = [];
  @ViewChild('csvReader') csvReader: any;

  uploadListener($event: any): void {


    let text = [];
    let files = $event.srcElement.files;

    if (this.isValidCSVFile(files[0])) {

      let input = $event.target;
      let reader = new FileReader();
      reader.readAsText(input.files[0]);

      reader.onload = () => {
        let csvData = reader.result;
        let csvRecordsArray = (<string>csvData).split(/\r\n|\n/);

        let headersRow = this.getHeaderArray(csvRecordsArray);

        this.records = this.getDataRecordsArrayFromCSVFile(csvRecordsArray, headersRow.length);
      };

      reader.onerror = function () {
        console.log('error is occured while reading file!');
      };

    } else {
      alert("Please import valid .csv file.");
      this.fileReset();
    }
  }

  getDataRecordsArrayFromCSVFile(csvRecordsArray: any, headerLength: any) {


    for (let i = 1; i < csvRecordsArray.length; i++) {
      let curruntRecord = (<string>csvRecordsArray[i]).split(',');
      if (curruntRecord.length == headerLength) {
        let csvRecord: ContractRecord = new ContractRecord();
        csvRecord.vendor = curruntRecord[0].trim();
        csvRecord.client = curruntRecord[1].trim();
        csvRecord.contractStratDate = curruntRecord[2].trim();
        csvRecord.contractEndDate = curruntRecord[3].trim();
        csvRecord.amount = curruntRecord[4].trim();
        csvRecord.description = curruntRecord[5].trim();


        console.log(`start date::${curruntRecord[2].trim()}`);
        this.contractCsvCopy.push(csvRecord);

      }

      this.contractFile = this.contractCsvCopy[0];

      this.getUploadFileContract();

      console.log("contract copy::" + this.contractCsvCopy[0].client);

    }
    return this.contractCsvCopy;
  }

  isValidCSVFile(file: any) {
    return file.name.endsWith(".csv");
  }

  getHeaderArray(csvRecordsArr: any) {
    let headers = (<string>csvRecordsArr[0]).split(',');
    let headerArray = [];
    for (let j = 0; j < headers.length; j++) {
      headerArray.push(headers[j]);
    }
    return headerArray;
  }

  fileReset() {
    this.csvReader.nativeElement.value = "";
    this.records = [];
  }

}

