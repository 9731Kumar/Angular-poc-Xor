export class ContractRecord {  
    public vendor: any;  
    public client: any;  
    public contractStratDate: any;  
    public contractEndDate: any;  
    public amount: any; 
    public description: any;
  } 