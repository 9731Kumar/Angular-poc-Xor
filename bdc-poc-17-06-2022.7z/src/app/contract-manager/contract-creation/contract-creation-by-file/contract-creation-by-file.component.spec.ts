import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ContractCreationByFileComponent } from './contract-creation-by-file.component';

describe('ContractCreationByFileComponent', () => {
  let component: ContractCreationByFileComponent;
  let fixture: ComponentFixture<ContractCreationByFileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ContractCreationByFileComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ContractCreationByFileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
