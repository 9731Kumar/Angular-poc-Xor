import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ApiServiceService } from 'src/app/services/api-service.service';
import { ContractCreationComponent } from '../contract-creation.component';

@Component({
  selector: 'app-contract-file',
  templateUrl: './contract-creation-by-file.component.html',
  styleUrls: ['./contract-creation-by-file.component.css']
})
export class ContractCreationByFileComponent implements OnInit {

  contractCreationForm!:FormGroup;
  @Input() vendorName:any;
  @Input() employeeName:any;
  // csvClient!: string;
  // csvContractStartDate!: Date;
  // csvContractEndDate!: Date;
  // amount!: number;
  // description:any;

  @Input() contractCopy!:any[]

  

  constructor() {    
    
   }

  ngOnInit(): void {
    // this.csvClient=this.contractCopy[0].client;
    // this.csvContractStartDate=this.contractCopy[0].contractStratDate;
    // this.csvContractEndDate=this.contractCopy[0].contractEndDate;
    // this.amount=this.contractCopy[0].amount;
    // this.description=this.contractCopy[0].description;

    //console.log("copy child::"+this.contractCopy[0].client);
    
    // this.contractCreationForm = new FormGroup({
    //   vendor: new FormControl(this.vendorName),
    //   client: new FormControl(this.csvClient),
    //   contractStratDate: new FormControl(this.csvContractStartDate),
    //   contractEndDate: new FormControl(this.csvContractEndDate),
    //   amount: new FormControl(this.amount),
    //   description: new FormControl(this.description),
    //   contractRaisedBy: new FormControl(this.employeeName)
    // })
    this.contractCreationForm = new FormGroup({
      vendor: new FormControl(this.vendorName),
      client: new FormControl(''),
      contractStratDate: new FormControl(''),
      contractEndDate: new FormControl(''),
      amount: new FormControl(''),
      description: new FormControl(''),
      contractRaisedBy: new FormControl(this.employeeName)
    })
   


    
  }

  get f(){
    return this.contractCreationForm.controls;
  }

  onSubmit(){
    console.log(this.contractCreationForm.value);
    
  }

}
