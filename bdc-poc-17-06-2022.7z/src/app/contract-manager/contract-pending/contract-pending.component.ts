import { Component, OnInit } from '@angular/core';
import { ApiServiceService } from 'src/app/services/api-service.service';
import { ReportGenerateService } from 'src/app/services/report-generate.service';

@Component({
  selector: 'app-contract-pending',
  templateUrl: './contract-pending.component.html',
  styleUrls: ['./contract-pending.component.css']
})
export class ContractPendingComponent implements OnInit {
  vendorPendingContracts:any[]=[];
  count:number = 5;
  p:number = 1;
  searchText:any;

  constructor(private apiService:ApiServiceService, private reportGenerator:ReportGenerateService) { }

  ngOnInit(): void {
    this.getVendorPendingContracts();
  }

  key:string='id';
  reverse:boolean=false
  Sort(key:any){
   this.key=key;
   this.reverse=!this.reverse;
  }

  getVendorPendingContracts(){
    this.apiService.getVendorPendingContracts().subscribe(res=>{
      this.vendorPendingContracts=res;
    })
  }

  fileDownload(){

    //Headers for CSV file
    let headers=['Contract No','Client', 'Contract Create Date', 'Start Date','End Date','Contract Value','Status', 'description','Raised By'];
    
    //HeaderList for iterating the array
    let headerList=['contractID','client','contractDate','contractStratDate','contractEndDate','amount','status','description','contractRaisedBy']

    this.reportGenerator.downloadFile(this.vendorPendingContracts,'pending contract list',headers,headerList);
  }

}
