import { Component, OnInit } from '@angular/core';
import Chart from 'chart.js/auto';
import { ApiServiceService } from 'src/app/services/api-service.service';

@Component({
    selector: 'app-contract-dashboard',
    templateUrl: './contract-dashboard.component.html',
    styleUrls: ['./contract-dashboard.component.css']
})
export class ContractDashboardComponent implements OnInit {


    totalRaisedContracts: number = 0;
    totalContractsPendingForApproval: number = 0;
    totalApprovedContracts: number = 0;

    totalContractsApprovedByMgr: number = 0;
    totalPendingInvoices: number = 0;
    totalApprovedInvoices: number = 0;


    constructor(private apiService: ApiServiceService) { }




    ngOnInit(): void {
        this.getRaisedContracts();
        this.getApprovedInvoices();
        this.getApprovedCOntractsByManager();
        this.getPendingInvoicesForApproval();
        
    }

    myChart(){
        const ctx = 'myChart';
        const myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Contracts raised', 'Contracts pending', 'Contracts Approved by client', 'Contracts Approved', 'Pending Invoices','Approved Invoices'],
                datasets: [{
                    label: '# numbers',
                    data: [this.totalRaisedContracts, this.totalContractsPendingForApproval,this.totalApprovedContracts,
                           this.totalContractsApprovedByMgr, this.totalPendingInvoices,this.totalApprovedInvoices],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(255, 206, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(153, 102, 255, 0.2)',
                        'rgba(255, 159, 64, 0.2)'
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)',
                        'rgba(255, 159, 64, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }

    getRaisedContracts() {
        this.apiService.getRaisedContractsForUser().subscribe(res => {
            this.totalRaisedContracts = res.length;

            const approved = res.filter((obj: any) => {
                return obj.status === 'ONGOING'
            });
            this.totalApprovedContracts = approved.length;

            const pending = res.filter((obj: any) => {
                return obj.status === 'PENDING'
            })
            this.totalContractsPendingForApproval = pending.length;
        })
    }

    getApprovedCOntractsByManager() {
        this.apiService.getAllApprovedContracts().subscribe(res => {
            this.totalContractsApprovedByMgr = res.length;
        })
    }

    getApprovedInvoices() {
        this.apiService.getApprovedInvoices().subscribe(res => {
            this.totalApprovedInvoices = res.length;
        })
    }

    getPendingInvoicesForApproval() {
        this.apiService.getApprovalPendingInvoices().subscribe(res => {
            this.totalPendingInvoices = res.length;
            this.myChart();
        })
    }

}
