import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contract-home',
  templateUrl: './contract-home.component.html',
  styleUrls: ['./contract-home.component.css']
})
export class ContractHomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
