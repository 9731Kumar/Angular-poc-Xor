import { Component, OnInit } from '@angular/core';
import { InvoiceReport } from 'src/app/modal/invoice-report';
import { ApiServiceService } from 'src/app/services/api-service.service';
import { ReportGenerateService } from 'src/app/services/report-generate.service';

@Component({
  selector: 'app-approved-invoices',
  templateUrl: './approved-invoices.component.html',
  styleUrls: ['./approved-invoices.component.css']
})
export class ApprovedInvoicesComponent implements OnInit {
  approvedInvoices:any[]=[];
  count:number = 5;
  p:number = 1;
  searchText:any;

  approvedInvoicesDisplayList:InvoiceReport[]=[];

  InvoiceReportList:InvoiceReport[]=[];

  constructor(private apiService:ApiServiceService, private reportGenerate:ReportGenerateService) { }

  ngOnInit(): void {
    this.getApprovedInvoices();
  }

  key:string='id';
  reverse:boolean=false
  Sort(key:any){
   this.key=key;
   this.reverse=!this.reverse;
  }

  getApprovedInvoices(){
    this.apiService.getApprovedInvoices().subscribe(res=>{
      this.approvedInvoices=res;
      this.approvedInvoicesDisplayList=[]
      for(let inv of this.approvedInvoices){
        let  invoice=new InvoiceReport(
           inv.contract.contractID,inv.contract.vendor,'', inv.id, inv.date,
           inv.invoiceAmount, inv.invoiceRaisedBy, inv.invoiceReviewedBy,inv.invoiceApprovedBy,'',inv.status
         );
   
         this.approvedInvoicesDisplayList.push(invoice);
       }
      
    })
  }

  fileDownload(){

    for(let inv of this.approvedInvoices){
      let  invoice=new InvoiceReport(
         inv.contract.contractID,inv.contract.vendor,'', inv.id, inv.date,
         inv.invoiceAmount, inv.invoiceRaisedBy, inv.invoiceReviewedBy,inv.invoiceApprovedBy,'',inv.status
       );
 
       this.InvoiceReportList.push(invoice);
     }
    //Headers for CSV file
    let headers=['Contract No','Vendor', 'Invoice No', 'Invoice Date','Invoice Amount','Invoice Raised By','Invoice Rewived By','Invoice Approved By','Status'];

    //HeaderList for iterating the array
    let headerList=['contractID','vendor','id','date','invoiceAmount','invoiceRaisedBy','invoiceReviewedBy','invoiceApprovedBy','status'];

    this.reportGenerate.downloadFile(this.InvoiceReportList,'approved invoice list',headers,headerList);
  }

}

