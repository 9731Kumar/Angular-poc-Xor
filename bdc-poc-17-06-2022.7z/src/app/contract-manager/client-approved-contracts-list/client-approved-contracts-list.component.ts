import { Component, OnInit } from '@angular/core';
import { ApiServiceService } from 'src/app/services/api-service.service';
import { PdfReportService } from 'src/app/services/pdf-report.service';
import { ReportGenerateService } from 'src/app/services/report-generate.service';

@Component({
  selector: 'app-client-approved-contracts-list',
  templateUrl: './client-approved-contracts-list.component.html',
  styleUrls: ['./client-approved-contracts-list.component.css']
})
export class ClientApprovedContractsListComponent implements OnInit {

  clientApprovedContracts:any[]=[];
  count:number = 5;
  p:number = 1;

  searchText:any;

  constructor(private apiService:ApiServiceService,
    private reportGenerate:ReportGenerateService,
    private pdfReport:PdfReportService) { }

  ngOnInit(): void {
    this.getAllClientApprovedCOntracts();
  }

  getAllClientApprovedCOntracts(){
    this.apiService.getAllApprovedContractsForVendor().subscribe(res=>{
      this.clientApprovedContracts=res;
    })
  }

  downloadContract(contract:any){
    let body=[['Contract Id',contract.contractID],['Vendor',contract.vendor],['Client',contract.client],
              ['Contract Date',contract.contractDate],['Contract Start Date',contract.contractStratDate],['Contract End Date',contract.contractEndDate],
              ['Contract Amount',contract.amount],['Contract Status',contract.status],['Description',contract.description],
              ['Contract Raised By',contract.contractRaisedBy],['Contract Approved By',contract.contractApprovedBy]]
    let pdfTitle="Contract Copy";
    let pdfName="contract_copy"
    this.pdfReport.convert(body,pdfTitle,pdfName);

  }


  fileDownload(){

    //Headers for CSV file
    let headers=['Contract No','Vendor', 'Client', 'Contract Date','Start Date','End Date','Contract Value','Status','Description', 'Contract Raised By','Contract Approved By'];

    //HeaderList for iterating the array
    let headerList=['contractID','vendor','client','contractDate','contractStratDate','contractEndDate','amount','status','description','contractRaisedBy','contractApprovedBy'];

    this.reportGenerate.downloadFile(this.clientApprovedContracts,'approved contract list',headers,headerList);
  }

  key:string='id';
  reverse:boolean=false
  Sort(key:any){
   this.key=key;
   this.reverse=!this.reverse;
  }

}
