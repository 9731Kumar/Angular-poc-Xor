import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClientApprovedContractsListComponent } from './client-approved-contracts-list.component';

describe('ClientApprovedContractsListComponent', () => {
  let component: ClientApprovedContractsListComponent;
  let fixture: ComponentFixture<ClientApprovedContractsListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClientApprovedContractsListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClientApprovedContractsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
